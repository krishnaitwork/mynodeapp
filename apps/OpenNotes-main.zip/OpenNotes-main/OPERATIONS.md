# OpenNotes Operations & Runbook

## Environments
Currently single environment (local development). For staging/production replicate steps with environment variables and process management (PM2/systemd/Docker).

## Required Software
- Node.js >= 18 (recommended for performance & security)
- npm (bundled with Node)
- (Optional) PowerShell 5+ scripts provided in docs

## Environment Variables
Create a `.env` file in `backend/` (optional):
```
PORT=5000
JWT_SECRET=replace_me_with_strong_secret
MAX_UPLOAD_MB=10
```
Then in `server.js` (future enhancement) load via `dotenv`. Currently secret uses default in code if unset.

## Start Sequence
1. `npm install` in `backend/` & `frontend/`
2. Initialize database: `npm run init-db` (backend)
3. Start backend: `npm run dev` (backend) – provides API on :5000
4. Start frontend: `npm run dev` (frontend) – dev server on :3000

## Health Check
- Endpoint: `GET /api/health`
- Response: `{ status: 'OK', timestamp: ISO8601 }`
Use in monitoring or container orchestrator readiness probes.

## Logs
- Console logs (stdout) only – rely on process manager (PM2) or container logs in production
- Key events logged: page fetch/update, errors, server start
- Recommendation: add structured logging with pino or winston for production

## Backup & Restore
SQLite file: `backend/opennotes.db`

Backup:
```
# Stop writes (stop backend) then copy
copy backend\opennotes.db backups\opennotes-<date>.db
```
Restore:
```
# Ensure server stopped
copy backups\opennotes-<date>.db backend\opennotes.db
```
Automate with scheduled task / cron in production.

## Rotation & Maintenance
| Task | Frequency | Action |
|------|-----------|--------|
| DB backup | Daily | Copy DB file |
| Dependency audit | Monthly | `npm audit --production` |
| Log review | Weekly | Scan for recurring errors |
| Security secret check | Quarterly | Rotate `JWT_SECRET` |

## Scaling Notes
- Single-process Express: scale via multiple instances + load balancer
- SQLite: safe for low concurrency; for scale migrate to Postgres
- Static assets: front-end build can be served by CDN

## Incident Response (Sample)
### Symptom: Autosave Flood (High PUT rate)
1. Check frontend console for repeated content diffs
2. Ensure normalized comparison still active in `MainEditor`
3. Restart frontend after clearing browser cache
4. Capture network HAR and open issue

### Symptom: Protected Page Shows Empty Content
1. Confirm unlock token header sent (`X-Page-Unlock`)
2. If expired, re-enter password to get new token
3. Verify backend logs for token verification errors

### Symptom: Search Missing Expected Page
1. Page content may be password protected (excluded)
2. Confirm query length ≥ 2 characters
3. Check content actually contains term (case insensitive LIKE)

## Deployment (Manual)
```
# Build frontend
cd frontend
npm install
npm run build

# Prepare backend
cd ../backend
npm install
# (Optional) copy frontend build
xcopy ..\frontend\dist .\public /E /I /Y
# Add express static serve code (future enhancement)
node server.js
```
```
pm2 starts methods
Navigate to the folder where the file lives, then:

cd C:\Projects\myapp
pm2 start ecosystem.config.js
pm2 save


This tells PM2 to load apps from that config.

🔹 Example for multiple apps in one file

If you want to manage app1 and app2 together:

module.exports = {
  apps: [
    {
      name: "app1",
      script: "server1.js",
      watch: true,
      max_restarts: 10,
      restart_delay: 5000
    },
    {
      name: "app2",
      script: "server2.js",
      watch: true,
      max_restarts: 10,
      restart_delay: 5000
    }
  ]
}


Then:

pm2 start ecosystem.config.js
pm2 save


✅ After that, PM2 will remember your config, restart apps automatically on crash, and restore them on Windows reboot (thanks to pm2-windows-startup).
```
Serve on reverse proxy (nginx) with caching rules for static assets.

## Observability TODO
- Add request timing middleware
- Add /metrics (Prometheus) endpoint
- Add structured logs (json)

---
Runbook provides operational baseline; expand as production needs grow.
