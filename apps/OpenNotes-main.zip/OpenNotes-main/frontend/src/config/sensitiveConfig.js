export const sensitiveConfig = {
  enabled: true,
  allowUnmask: true,
  showPartial: true,
  maskCharacter: '*',
  maskLength: 6,
  separators: [':', '=', '\\n'],
  sensitiveKeywords: ['password', 'api_key', 'secret', 'passwd']
};

export const hasSensitiveContent = (text) => {
  if (!sensitiveConfig.enabled || !text) return false;
  const lower = text.toLowerCase();
  return sensitiveConfig.sensitiveKeywords.some(k => lower.includes(k));
};

export const maskSensitiveContent = (text) => {
  if (!text) return text;
  const mask = sensitiveConfig.maskCharacter.repeat(sensitiveConfig.maskLength);
  // naive replacement for keywords
  let out = text;
  sensitiveConfig.sensitiveKeywords.forEach(k => {
    const re = new RegExp(`(${k}\\s*[:=\\n\\s]+)(\\S+)`, 'gi');
    out = out.replace(re, `$1${mask}`);
  });
  return out;
};

export const addSensitiveKeywords = (kw) => {
  if (!sensitiveConfig.sensitiveKeywords.includes(kw)) sensitiveConfig.sensitiveKeywords.push(kw);
};

export const removeSensitiveKeywords = (kw) => {
  sensitiveConfig.sensitiveKeywords = sensitiveConfig.sensitiveKeywords.filter(k => k !== kw);
};

export const updateSensitiveConfig = (patch) => {
  Object.assign(sensitiveConfig, patch);
};

export default sensitiveConfig;