import React from 'react';
import { AppProvider } from './context/AppContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import Sidebar from './components/Sidebar';
import MainEditor from './components/MainEditor';
import CalendarView from './components/calendar/CalendarView';
import TabbedNotes from './components/TabbedNotes';
import { useApp } from './context/AppContext';
import LoginForm from './components/LoginForm';
import { Routes, Route, useLocation } from 'react-router-dom';
import KeepPage from './pages/KeepPage';

function AppContent() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-400">Loading OpenNotes...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginForm />;
  }

  return (
    <AppProvider>
      <AppInner />
    </AppProvider>
  );
}

function AppInner() {
  const { state } = useApp();
  const location = useLocation();

  // If we're on /keep, render KeepPage standalone without OpenNotes chrome (sidebar/header)
  if (location.pathname && location.pathname.startsWith('/keep')) {
    return (
      <div className="h-screen w-full bg-gray-100 dark:bg-gray-900">
        <Routes>
          <Route path="/keep" element={<KeepPage />} />
        </Routes>
      </div>
    );
  }

  return (
    <div className="h-screen flex bg-gray-100 dark:bg-gray-900">
      <Sidebar />
      <Routes>
        <Route path="/keep" element={<KeepPage />} />
        <Route path="/" element={state.calendarOpen ? <CalendarView /> : state.tabbedOpen ? <TabbedNotes /> : <MainEditor />} />
      </Routes>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
