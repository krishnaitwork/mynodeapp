import { axiosInstance } from './api';

// Reuse the app's shared axios instance so Keep uses the same runtime API base,
// headers, and interceptors. We still namespace Keep endpoints under /smartkeep
const api = axiosInstance;
api.defaults.timeout = 10000;

api.interceptors.request.use(
  (config) => {
    // console.log(`Keep API ${config.method?.toUpperCase()} ${config.url}`);
    return config;
  },
  (error) => Promise.reject(error)
);

api.interceptors.response.use(
  (response) => response,
  (error) => Promise.reject(error)
);

export const keepAPI = {
  getAllNotes: async (filters = {}) => {
    const params = new URLSearchParams();
    if (filters.search) params.append('search', filters.search);
    if (filters.category && filters.category !== 'All') params.append('category', filters.category);
    if (filters.pinned !== undefined) params.append('pinned', filters.pinned);
    if (filters.archived !== undefined) params.append('archived', filters.archived);
    const response = await api.get(`/smartkeep/notes?${params.toString()}`);
    return response.data;
  },
  getNoteById: async (id) => {
    const response = await api.get(`/smartkeep/notes/${id}`);
    return response.data;
  },
  createNote: async (noteData) => {
    const response = await api.post('/smartkeep/notes', noteData);
    return response.data;
  },
  updateNote: async (id, noteData) => {
    const response = await api.put(`/smartkeep/notes/${id}`, noteData);
    return response.data;
  },
  deleteNote: async (id) => {
    const response = await api.delete(`/smartkeep/notes/${id}`);
    return response.data;
  },
  togglePin: async (id) => {
    const response = await api.patch(`/smartkeep/notes/${id}/pin`);
    return response.data;
  },
  toggleArchive: async (id) => {
    const response = await api.patch(`/smartkeep/notes/${id}/archive`);
    return response.data;
  },
  getCategories: async () => {
    const response = await api.get('/smartkeep/notes/categories');
    return response.data;
  },
  exportNotes: async () => {
    const response = await api.get('/smartkeep/notes/export');
    return response.data;
  },
  importNotes: async (notesData) => {
    const response = await api.post('/smartkeep/notes/import', { notes: notesData });
    return response.data;
  },
  getStats: async () => {
    const response = await api.get('/smartkeep/notes/stats');
    return response.data;
  },
  healthCheck: async () => {
    const response = await api.get('/smartkeep/health');
    return response.data;
  }
};

export default api;