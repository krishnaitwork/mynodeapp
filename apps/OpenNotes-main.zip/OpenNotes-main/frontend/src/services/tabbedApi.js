import apiService from './api';

function authHeaders() {
  const headers = { 'Content-Type': 'application/json' };
  try {
    const token = localStorage.getItem('auth_token');
    if (token) headers['Authorization'] = `Bearer ${token}`;
  } catch (_) {}
  return headers;
}

function baseUrl() {
  const base = apiService.getApiBase();
  return base.replace(/\/$/, '') + '/tabbed-notes';
}

export async function listTabs() {
  const res = await fetch(baseUrl(), { headers: authHeaders() });
  if (!res.ok) throw new Error(`Failed to list tabs: ${res.status}`);
  const data = await res.json();
  return data.tabs || [];
}

export async function getTab(id) {
  const res = await fetch(`${baseUrl()}/${id}`, { headers: authHeaders() });
  if (!res.ok) throw new Error(`Failed to get tab: ${res.status}`);
  return res.json();
}

export async function createTab(payload) {
  const res = await fetch(baseUrl(), { method: 'POST', headers: authHeaders(), body: JSON.stringify(payload) });
  if (!res.ok) throw new Error(`Failed to create tab: ${res.status}`);
  return res.json();
}

export async function updateTab(id, payload) {
  const res = await fetch(`${baseUrl()}/${id}`, { method: 'PUT', headers: authHeaders(), body: JSON.stringify(payload) });
  if (!res.ok) throw new Error(`Failed to update tab: ${res.status}`);
  return res.json();
}

export async function deleteTab(id) {
  const res = await fetch(`${baseUrl()}/${id}`, { method: 'DELETE', headers: authHeaders() });
  if (!res.ok) throw new Error(`Failed to delete tab: ${res.status}`);
  return { deleted: true };
}

export default { listTabs, getTab, createTab, updateTab, deleteTab };
