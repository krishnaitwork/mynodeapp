import axios from 'axios';

// Determine API base URL with runtime override capability.
// Priority order:
// 1. window.OPENNOTES_API_BASE (set by an inline <script> BEFORE the app bundle)
// 2. localStorage 'apiBaseOverride'
// 3. Vite env VITE_API_URL
// 4. Fallback http://localhost:5000
function resolveInitialApiBase() {
  let base = import.meta.env?.VITE_API_URL || 'http://localhost:5000';
  try {
    if (typeof window !== 'undefined') {
      // Protect against someone setting these runtime overrides to the
      // literal string 'undefined' or 'null' (which can happen in some
      // deployment scripts). Treat those as absent.
      const winBase = (typeof window.OPENNOTES_API_BASE === 'string') ? window.OPENNOTES_API_BASE.trim() : window.OPENNOTES_API_BASE;
      if (winBase && winBase !== 'undefined' && winBase !== 'null') {
        base = winBase;
      } else {
        const stored = localStorage.getItem('apiBaseOverride');
        if (stored && stored !== 'undefined' && stored !== 'null') base = stored;
      }
    }
  } catch (_) { /* ignore access errors */ }
  // Normalize: ensure no trailing slash; ensure trailing /api if not already included
  base = base.replace(/\/$/, '');
  if (!/\/api$/i.test(base)) {
    base = base + '/api';
  }
  return base;
}

let currentApiBase = resolveInitialApiBase();

const api = axios.create({
  baseURL: currentApiBase,
  headers: { 'Content-Type': 'application/json' },
});

// Re-export the axios instance for other service modules to share the same base and interceptors
export { api as axiosInstance };

// Attach page unlock token if available (sessionStorage keyed by page unlock)
api.interceptors.request.use((config) => {
  if (config.url && /\/pages\/(\d+)/.test(config.url) && config.method === 'get') {
    const match = config.url.match(/\/pages\/(\d+)/);
    if (match) {
      const pageId = match[1];
      const token = sessionStorage.getItem(`pageUnlockToken_${pageId}`);
      if (token) {
        config.headers['X-Page-Unlock'] = token;
      }
    }
  }
  return config;
});

// Add auth token to requests if available
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('auth_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Authentication
export const authApi = {
  login: (username, password) => api.post('/auth/login', { username, password }),
  register: (username, password) => api.post('/auth/register', { username, password }),
  verify: (token) => api.get('/auth/verify', {
    headers: { Authorization: `Bearer ${token}` }
  }),
  getMe: () => api.get('/auth/me'),
};

// Page Security
export const pageSecurityApi = {
  setPassword: (pageId, password) => api.post(`/pages/${pageId}/set-password`, { password }),
  removePassword: (pageId) => api.post(`/pages/${pageId}/remove-password`),
  verifyPassword: (pageId, password) => api.post(`/pages/${pageId}/verify-password`, { password }),
  unlockPage: (pageId, password) => api.post(`/pages/${pageId}/unlock`, { password }),
};

// Notebooks
export const notebookApi = {
  getAll: () => api.get('/notebooks'),
  create: (name) => api.post('/notebooks', { name }),
  update: (id, name) => api.put(`/notebooks/${id}`, { name }),
  delete: (id) => api.delete(`/notebooks/${id}`),
};

// Sections
export const sectionApi = {
  getByNotebook: (notebookId) => api.get(`/notebooks/${notebookId}/sections`),
  create: (notebookId, name) => api.post('/sections', { notebook_id: notebookId, name }),
  update: (id, updates) => api.put(`/sections/${id}`, updates),
  delete: (id) => api.delete(`/sections/${id}`),
  reorder: (notebookId, sections) => api.put(`/notebooks/${notebookId}/sections/reorder`, { sections }),
};

// Pages
export const pageApi = {
  getBySection: (sectionId) => api.get(`/sections/${sectionId}/pages`),
  getById: (id) => api.get(`/pages/${id}`),
  create: (sectionId, title, content) => api.post('/pages', { section_id: sectionId, title, content }),
  update: (id, updates) => api.put(`/pages/${id}`, updates),
  delete: (id) => api.delete(`/pages/${id}`),
  reorder: (sectionId, pages) => api.put(`/sections/${sectionId}/pages/reorder`, { pages }),
};

// Search
export const searchApi = {
  search: (query) => api.get(`/search?q=${encodeURIComponent(query)}`),
};

// Convenience methods
const apiService = {
  // Runtime base URL utilities
  getApiBase: () => currentApiBase,
  setApiBase: (newBase) => {
  if (!newBase || typeof newBase !== 'string') return currentApiBase;
  const trimmed = newBase.trim();
  if (trimmed === 'undefined' || trimmed === 'null') return currentApiBase;
  let normalized = trimmed.replace(/\/$/, '');
  if (!/\/api$/i.test(normalized)) normalized += '/api';
  currentApiBase = normalized;
  api.defaults.baseURL = currentApiBase;
  try { localStorage.setItem('apiBaseOverride', trimmed); } catch(_) {}
  return currentApiBase;
  },
  clearApiBaseOverride: () => {
    try { localStorage.removeItem('apiBaseOverride'); } catch(_) {}
    currentApiBase = resolveInitialApiBase();
    api.defaults.baseURL = currentApiBase;
    return currentApiBase;
  },
  // Auth
  login: (username, password) => authApi.login(username, password).then(res => res.data),
  register: (username, password) => authApi.register(username, password).then(res => res.data),
  verifyToken: (token) => authApi.verify(token).then(res => res.data),
  getMe: () => authApi.getMe().then(res => res.data),

  // Page Security
  setPagePassword: (pageId, password) => pageSecurityApi.setPassword(pageId, password).then(res => res.data),
  removePagePassword: (pageId) => pageSecurityApi.removePassword(pageId).then(res => res.data),
  verifyPagePassword: (pageId, password) => pageSecurityApi.verifyPassword(pageId, password).then(res => res.data),
  unlockPage: (pageId, password) => pageSecurityApi.unlockPage(pageId, password).then(res => res.data),
  storePageUnlockToken: (pageId, token) => {
    if (token) {
      sessionStorage.setItem(`pageUnlockToken_${pageId}`, token);
    }
  },
  getStoredUnlockToken: (pageId) => sessionStorage.getItem(`pageUnlockToken_${pageId}`),
  clearPageUnlockToken: (pageId) => sessionStorage.removeItem(`pageUnlockToken_${pageId}`),
};

export default apiService;
