import axios from 'axios';
import apiService from './api';

function resolveCalendarBase() {
  // Prefer the app-level runtime API base (it normalizes /api and guards against
  // literal 'undefined' values). This ensures requests go to the backend host
  // (for example http://localhost:5000) instead of the frontend origin.
  try {
    if (apiService && typeof apiService.getApiBase === 'function') {
      const b = apiService.getApiBase();
      if (b && typeof b === 'string' && b !== 'undefined' && b !== 'null') {
        return b.replace(/\/$/, '') + '/calendar';
      }
    }
  } catch (_) {}

  // Fallback: respect VITE_API_URL if set at build time, otherwise use a
  // relative path so same-origin requests hit the current host.
  if (import.meta.env?.VITE_API_URL) {
    return `${import.meta.env.VITE_API_URL.replace(/\/$/, '')}/api/calendar`;
  }
  return '/api/calendar';
}

const base = resolveCalendarBase();

export async function listTasks(from, to) {
  const params = {};
  if (from) params.from = from;
  if (to) params.to = to;
  const res = await axios.get(base, { params });
  return res.data;
}

export async function createTask(payload) {
  const res = await axios.post(base, payload);
  return res.data;
}

export async function updateTask(id, payload) {
  const res = await axios.put(`${base}/${id}`, payload);
  return res.data;
}

export async function deleteTask(id) {
  const res = await axios.delete(`${base}/${id}`);
  return res.data;
}

export async function rollover() {
  const res = await axios.post(`${base}/rollover`);
  return res.data;
}
