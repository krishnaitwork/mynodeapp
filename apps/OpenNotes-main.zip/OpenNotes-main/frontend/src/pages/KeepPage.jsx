import React, { useState, useEffect } from 'react';
import KeepHeader from '../components/KeepHeader';
import { useNavigate } from 'react-router-dom';
import KeepNoteCard from '../components/KeepNoteCard';
import KeepNoteModal from '../components/KeepNoteModal';
import KeepDeleteConfirmModal from '../components/KeepDeleteConfirmModal';
import KeepSensitiveConfigModal from '../components/KeepSensitiveConfigModal';
import { keepAPI } from '../services/keepApi';
import { useApp } from '../context/AppContext';

const KeepPage = () => {
  const [notes, setNotes] = useState([]);
  const [filteredNotes, setFilteredNotes] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [showArchived, setShowArchived] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingNote, setEditingNote] = useState(null);
  const [categories, setCategories] = useState(['Work','Personal','Home','Finance']);
  const { state, dispatch } = useApp();
  const [loading, setLoading] = useState(true);
  const [isConfigOpen, setIsConfigOpen] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [noteToDelete, setNoteToDelete] = useState(null);

  useEffect(() => { loadNotes(); loadCategories(); }, []);

  useEffect(() => {
    if (!notes || !Array.isArray(notes)) { setFilteredNotes([]); return; }
    const q = (searchTerm || '').toLowerCase();
    let filtered = notes.filter(note => {
      const matchesSearch = q === '' || (note.title && note.title.toLowerCase().includes(q)) || (note.content && note.content.toLowerCase().includes(q)) || (note.category && note.category.toLowerCase().includes(q));
      const matchesCategory = selectedCategory === '' || note.category === selectedCategory;
      const matchesArchived = showArchived ? note.archived === 1 : note.archived === 0;
      return matchesSearch && matchesCategory && matchesArchived;
    });
    filtered.sort((a,b) => (b.pinned - a.pinned) || (new Date(b.LastModifiedDate) - new Date(a.LastModifiedDate)));
    setFilteredNotes(filtered);
  }, [notes, searchTerm, selectedCategory, showArchived]);

  const loadNotes = async () => {
    setLoading(true);
    try {
      const data = await keepAPI.getAllNotes();
      setNotes(Array.isArray(data) ? data : (data.data || []));
    } catch (err) { console.error(err); setNotes([]); }
    setLoading(false);
  };

  const loadCategories = async () => {
    try {
      const data = await keepAPI.getCategories();
      setCategories(Array.isArray(data) ? data : (data.data || ['Work','Personal','Home','Finance']));
    } catch (err) { console.error(err); }
  };

  const handleCreateNote = () => { setEditingNote(null); setIsModalOpen(true); };
  const handleEditNote = (note) => { setEditingNote(note); setIsModalOpen(true); };
  const handleSaveNote = async (noteData) => {
    try {
      if (editingNote) {
        const updated = await keepAPI.updateNote(editingNote.id, noteData);
        setNotes(notes.map(n => n.id === editingNote.id ? updated : n));
      } else {
        const created = await keepAPI.createNote(noteData);
        setNotes([created, ...notes]);
      }
      setIsModalOpen(false);
    } catch (err) { console.error(err); }
  };

  const handleDeleteNote = async (note) => {
    setNoteToDelete(note);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (!noteToDelete) return;
    try { await keepAPI.deleteNote(noteToDelete.id); setNotes(notes.filter(n => n.id !== noteToDelete.id)); } catch (err) { console.error(err); }
    setShowDeleteConfirm(false); setNoteToDelete(null);
  };

  const navigate = useNavigate();

  const returnToOpenNotes = () => {
    // Try to navigate back to the app root; if Keep was opened in a separate tab from another origin,
    // fallback to replacing location to the root of the current origin.
    try {
      navigate('/');
    } catch (e) {
      window.location.href = '/';
    }
  };

  if (loading) return <div className="flex items-center justify-center h-screen">Loading Keep...</div>;

  return (
    <div className="h-screen flex flex-col bg-background">
      <KeepHeader
        darkMode={state.darkMode}
        onToggleTheme={() => dispatch({ type: 'TOGGLE_DARK_MODE' })}
        onExport={() => {}}
        onImport={() => {}}
        showArchived={showArchived}
        onToggleArchived={() => setShowArchived(!showArchived)}
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        categories={categories}
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
        onCreateNote={handleCreateNote}
        onOpenConfig={() => setIsConfigOpen(true)}
        returnToOpenNotes={returnToOpenNotes}
      />

      <div className="p-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 overflow-auto">
        {filteredNotes.map(note => (
          <KeepNoteCard key={note.id} note={note} onEdit={handleEditNote} onDelete={() => handleDeleteNote(note)} onTogglePin={() => {}} onToggleArchive={() => {}} />
        ))}
      </div>

      {isModalOpen && <KeepNoteModal note={editingNote} categories={categories} isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onSave={handleSaveNote} />}
      {showDeleteConfirm && <KeepDeleteConfirmModal isOpen={showDeleteConfirm} onClose={() => setShowDeleteConfirm(false)} onConfirm={confirmDelete} noteTitle={noteToDelete?.title} />}
      {isConfigOpen && <KeepSensitiveConfigModal isOpen={isConfigOpen} onClose={() => setIsConfigOpen(false)} />}
    </div>
  );
};

export default KeepPage;