import React, { useEffect, useMemo, useRef, useState } from "react";
import { Plus, X, Save, Edit3, Download, Upload, Trash2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import tabbedApi from '../services/tabbedApi';

// Simple uid fallback for local-only created items
const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

function firstLine(text) {
  const t = (text || "").replace(/\r/g, "");
  const line = t.split("\n")[0].trim();
  return line || "Untitled";
}

function stripHtml(html) {
  const tmp = document.createElement("div");
  tmp.innerHTML = html;
  return tmp.textContent || tmp.innerText || "";
}

export default function TabbedNotes() {
  const [tabs, setTabs] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [renamingId, setRenamingId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const contentRef = useRef(null);

  useEffect(() => {
    let mounted = true;
    async function load() {
      try {
        const data = await tabbedApi.listTabs();
        if (!mounted) return;
        setTabs(data.length ? data : [{ id: uid(), title: 'Welcome', content: '<h2>Welcome</h2><p>Start typing.</p>' }]);
        setActiveId(data[0]?.id || null);
      } catch (e) {
        setError('Failed to load notes from server. Check your connection.');
        setTabs([{ id: uid(), title: 'Welcome', content: '<h2>Welcome</h2><p>Start typing.</p>' }]);
      } finally {
        setLoading(false);
      }
    }
    load();
    return () => { mounted = false; };
  }, []);

  const activeIndex = useMemo(() => tabs.findIndex(t => t.id === activeId), [tabs, activeId]);
  const activeTab = tabs[activeIndex] || tabs[0];

  function addTab() {
    const t = { id: uid(), title: 'Untitled', content: '', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    setTabs(prev => [...prev, t]);
    setActiveId(t.id);
    setRenamingId(t.id);
    // try to persist
    tabbedApi.createTab({ title: t.title, content: t.content }).then(remote => {
      setTabs(prev => prev.map(p => p.id === t.id ? { ...remote } : p));
      setActiveId(remote.id);
    }).catch(()=>{
      setError('Failed to create tab on server. Your changes are only local until connection is restored.');
    });
  }

  function closeTab(id) {
    setTabs(prev => {
      const idx = prev.findIndex(t => t.id === id);
      const next = prev.filter(t => t.id !== id);
      if (!next.length) {
        const fresh = { id: uid(), title: 'Untitled', content: '', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
        setActiveId(fresh.id);
        return [fresh];
      }
      if (id === activeId) {
        const newIdx = Math.max(0, idx - 1);
        setActiveId(next[newIdx].id);
      }
      // try delete remotely
      tabbedApi.deleteTab(id).catch(()=>{ setError('Failed to delete tab on server.'); });
      return next;
    });
  }

  function updateActiveContent(html) {
    setTabs(prev => {
      const copy = [...prev];
      const i = copy.findIndex(t => t.id === activeId);
      if (i >= 0) {
        const derivedTitle = copy[i].title === 'Untitled' || copy[i].title === '' ? firstLine(stripHtml(html)) : copy[i].title;
        copy[i] = { ...copy[i], content: html, title: derivedTitle, updatedAt: new Date().toISOString() };
        // debounce/save remote
        const save = copy[i];
        tabbedApi.updateTab(save.id, { title: save.title, content: save.content }).catch(()=>{ setError('Failed to save changes to server.'); });
      }
      return copy;
    });
  }

  function renameTab(id, title) {
    setTabs(prev => prev.map(t => t.id === id ? { ...t, title } : t));
    tabbedApi.updateTab(id, { title }).catch(()=>{ setError('Failed to rename tab on server.'); });
  }

  if (loading) return <div className="p-6">Loading...</div>;

  return (
    <div className="h-screen w-full bg-gradient-to-b from-slate-50 to-white text-slate-800 flex flex-col">
      <div className="w-full px-4 pt-4 flex-1">
        {error && (
          <div className="mb-4 px-4 py-2 bg-yellow-100 text-yellow-800 rounded">{error}</div>
        )}
        <div className="flex items-center gap-2 overflow-x-auto pb-2">
          <AnimatePresence initial={false}>
            {tabs.map((t) => (
              <motion.div key={t.id} layout initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }}>
                <div className={`group flex items-center gap-2 rounded-2xl border px-3 py-1.5 shadow-sm ${t.id === activeId ? "bg-white border-slate-300" : "bg-slate-100 border-transparent hover:bg-slate-200"}`}>
                  {renamingId === t.id ? (
                    <input
                      className="bg-transparent outline-none text-sm w-40"
                      defaultValue={t.title}
                      onBlur={(e)=> { renameTab(t.id, e.target.value.trim() || "Untitled"); setRenamingId(null); }}
                      onKeyDown={(e)=> { if (e.key === "Enter") { e.currentTarget.blur(); } }}
                    />
                  ) : (
                    <button onClick={() => setActiveId(t.id)} onDoubleClick={() => setRenamingId(t.id)} className={`text-sm truncate max-w-[10rem] ${t.id === activeId ? "font-medium" : ""}`}>
                      {t.title || "Untitled"}
                    </button>
                  )}
                  <button title="Rename" className="opacity-0 group-hover:opacity-100 transition" onClick={() => setRenamingId(t.id)}>
                    <Edit3 size={16} />
                  </button>
                  <button title="Close" className="opacity-60 hover:opacity-100" onClick={() => closeTab(t.id)}>
                    <X size={16} />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          <button onClick={addTab} className="flex items-center gap-1 rounded-full border border-dashed px-3 py-1.5 hover:bg-slate-100">
            <Plus size={16}/> Add
          </button>
        </div>

  <div className="mt-4 rounded-3xl border bg-white shadow-sm flex flex-col flex-1 h-full">
          <div className="flex items-center justify-between px-3 py-2 border-b rounded-t-3xl bg-slate-50">
            <div className="flex items-center gap-2 text-xs text-slate-600">
              <span className="px-2 py-1 rounded-full bg-white border shadow-sm">Rich text · contentEditable</span>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => { if (!activeTab) return; if (!confirm('Clear this tab?')) return; updateActiveContent(''); }} className="inline-flex items-center gap-2 rounded-xl px-3 py-1.5 bg-white border shadow-sm hover:shadow">
                <Trash2 size={16}/> Clear
              </button>
            </div>
          </div>
          <div className="flex-1 overflow-auto p-4 h-full">
            <div
              ref={contentRef}
              className="prose max-w-none w-full h-full outline-none min-h-[40vh]"
              contentEditable
              suppressContentEditableWarning
              onInput={(e) => updateActiveContent(e.currentTarget.innerHTML)}
              onBlur={(e) => updateActiveContent(e.currentTarget.innerHTML)}
              dangerouslySetInnerHTML={{ __html: activeTab?.content || "" }}
            />
          </div>
          <footer className="flex items-center justify-between text-xs text-slate-500 px-4 py-2 border-t bg-slate-50 rounded-b-3xl">
            <div className="flex items-center gap-2">
              <Save size={14}/> Auto-saved
            </div>
            {activeTab && (
              <div>
                  {activeTab && (
                    <>
                      {activeTab.updatedAt ? `Updated ${new Date(activeTab.updatedAt).toLocaleString()}` : ''}
                      {activeTab.createdAt ? ` · Created ${new Date(activeTab.createdAt).toLocaleString()}` : ''}
                    </>
                  )}
                </div>
            )}
          </footer>
        </div>

      </div>
    </div>
  );
}
