import React, { useState, useEffect } from 'react';
import { listTasks, createTask, updateTask, deleteTask, rollover } from '../../services/calendarApi';
import DayTaskList from './DayTaskList';
import TaskFormModal from './TaskFormModal';
import dayjs from 'dayjs';

export default function CalendarView() {
  const [selectedDate, setSelectedDate] = useState(dayjs().format('YYYY-MM-DD'));
  const [tasks, setTasks] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [loading, setLoading] = useState(false);

  const loadForDate = async (date) => {
    setLoading(true);
    try {
      const data = await listTasks(date, date);
      setTasks(data || []);
    } catch (err) {
      console.error('Failed to load tasks', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadForDate(selectedDate); }, [selectedDate]);

  const handleNew = () => { setEditing(null); setModalOpen(true); };

  const handleSave = async (payload) => {
    try {
      if (editing) {
        await updateTask(editing.id, payload);
      } else {
        await createTask(payload);
      }
      setModalOpen(false);
      loadForDate(selectedDate);
    } catch (err) { console.error(err); }
  };

  const handleEdit = (task) => { setEditing(task); setModalOpen(true); };
  const handleDelete = async (task) => { if (!confirm('Delete task?')) return; await deleteTask(task.id); loadForDate(selectedDate); };
  const handleToggleComplete = async (task) => { await updateTask(task.id, { is_completed: task.is_completed ? 0 : 1 }); loadForDate(selectedDate); };

  const handlePrev = () => setSelectedDate(dayjs(selectedDate).subtract(1, 'day').format('YYYY-MM-DD'));
  const handleNext = () => setSelectedDate(dayjs(selectedDate).add(1, 'day').format('YYYY-MM-DD'));

  const handleRollover = async () => {
    const res = await rollover();
    alert(`Rollover moved ${res.moved} tasks`);
    loadForDate(selectedDate);
  };

  return (
    <div className="flex-1 p-4 overflow-auto">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <button onClick={handlePrev} className="px-2 py-1 border rounded">◀</button>
          <input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} className="px-2 py-1 border rounded" />
          <button onClick={handleNext} className="px-2 py-1 border rounded">▶</button>
          <button onClick={handleNew} className="px-2 py-1 bg-blue-600 text-white rounded">New</button>
        </div>
        <div>
          <button onClick={handleRollover} className="px-2 py-1 border rounded">Run Rollover</button>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded shadow-sm">
        {loading ? <div className="p-4">Loading...</div> : <DayTaskList tasks={tasks} onEdit={handleEdit} onDelete={handleDelete} onToggleComplete={handleToggleComplete} />}
      </div>

      <TaskFormModal isOpen={modalOpen} initial={editing} onClose={() => setModalOpen(false)} onSave={handleSave} />
    </div>
  );
}
