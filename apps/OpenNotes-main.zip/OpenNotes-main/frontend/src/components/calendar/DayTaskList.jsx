import React from 'react';

export default function DayTaskList({ tasks = [], onEdit, onDelete, onToggleComplete }) {
  if (!tasks.length) return <div className="p-3 text-sm text-gray-500">No tasks for this day</div>;

  return (
    <div className="space-y-2 p-2">
      {tasks.map(task => (
        <div key={task.id} className="border rounded p-2 flex items-start gap-2">
          <div>
            <input type="checkbox" checked={!!task.is_completed} onChange={() => onToggleComplete(task)} />
          </div>
          <div className="flex-1">
            <div className={`font-medium ${task.is_completed ? 'line-through text-gray-400' : ''}`}>{task.title}</div>
            {task.notes && <div className="text-xs text-gray-500 mt-1">{task.notes}</div>}
            <div className="text-xs text-gray-400 mt-1">Due: {task.due_date}</div>
          </div>
          <div className="flex flex-col gap-1">
            <button className="text-sm text-blue-600" onClick={() => onEdit(task)}>Edit</button>
            <button className="text-sm text-red-600" onClick={() => onDelete(task)}>Delete</button>
          </div>
        </div>
      ))}
    </div>
  );
}
