import React, { useState, useEffect } from 'react';

export default function TaskFormModal({ isOpen, onClose, onSave, initial }) {
  const [title, setTitle] = useState(initial?.title || '');
  const [notes, setNotes] = useState(initial?.notes || '');
  const [dueDate, setDueDate] = useState(initial?.due_date || '');
  const [isCompleted, setIsCompleted] = useState(!!initial?.is_completed);

  useEffect(() => {
    if (initial) {
      setTitle(initial.title || '');
      setNotes(initial.notes || '');
      setDueDate(initial.due_date || '');
      setIsCompleted(!!initial.is_completed);
    } else {
      setTitle(''); setNotes(''); setDueDate(''); setIsCompleted(false);
    }
  }, [initial, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({ title, notes, due_date: dueDate, is_completed: isCompleted });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="bg-white dark:bg-gray-800 rounded shadow p-4 w-96">
        <h3 className="text-lg font-medium mb-2">{initial ? 'Edit Task' : 'New Task'}</h3>
        <form onSubmit={handleSubmit} className="space-y-2">
          <input className="w-full px-2 py-1 border rounded" value={title} onChange={e => setTitle(e.target.value)} placeholder="Title" required />
          <textarea className="w-full px-2 py-1 border rounded" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Notes" rows={3} />
          <input type="date" className="w-full px-2 py-1 border rounded" value={dueDate} onChange={e => setDueDate(e.target.value)} required />
          <label className="flex items-center gap-2"><input type="checkbox" checked={isCompleted} onChange={e => setIsCompleted(e.target.checked)} /> Completed</label>
          <div className="flex justify-end gap-2">
            <button type="button" onClick={onClose} className="px-3 py-1 border rounded">Cancel</button>
            <button type="submit" className="px-3 py-1 bg-blue-600 text-white rounded">Save</button>
          </div>
        </form>
      </div>
    </div>
  );
}
