import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import PagePasswordModal from './PagePasswordModal';
import ConfirmModal from './ConfirmModal';
import { 
  ChevronDown, 
  ChevronRight, 
  Plus, 
  BookOpen, 
  FileText, 
  Folder,
  X,
  Menu,
  ChevronLeft,
  Pin,
  Trash2,
  GripVertical,
  MoreVertical,
  Lock,
  Shield
} from 'lucide-react';

const Sidebar = () => {
  const { 
    state, 
    dispatch, 
    createNotebook, 
    createSection, 
    createPage, 
    selectPage, 
    updatePage,
    deleteNotebook,
    deleteSection,
    deletePage,
    reorderSections,
    reorderPages,
    toggleSectionPin,
    togglePagePin
  } = useApp();
  const [newNotebookName, setNewNotebookName] = useState('');
  const [newSectionName, setNewSectionName] = useState('');
  const [showNewNotebook, setShowNewNotebook] = useState(false);
  const [showNewSection, setShowNewSection] = useState(false);
  const [editingPageId, setEditingPageId] = useState(null);
  const [editingPageTitle, setEditingPageTitle] = useState('');
  const editingOriginalTitleRef = useRef('');
  const editingCanceledRef = useRef(false);
  const [draggedSection, setDraggedSection] = useState(null);
  const [draggedPage, setDraggedPage] = useState(null);
  const [dragOverIndex, setDragOverIndex] = useState(null);
  const [showSectionMenu, setShowSectionMenu] = useState(null);
  const [showPageMenu, setShowPageMenu] = useState(null);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [passwordModalPageId, setPasswordModalPageId] = useState(null);
  const [isSettingPassword, setIsSettingPassword] = useState(false);
  const sidebarRef = useRef(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmContext, setConfirmContext] = useState({ type: null, id: null, title: '', payload: null });
  const [pageSearch, setPageSearch] = useState('');

  // Derived filtered pages based on client-side search (no API calls)
  const filteredPages = (() => {
    const q = (pageSearch || '').trim().toLowerCase();
    if (!q) return state.pages || [];
    return (state.pages || []).filter(p => (p.title || 'Untitled Page').toLowerCase().includes(q));
  })();

  // Close menus when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (sidebarRef.current && !sidebarRef.current.contains(event.target)) {
        setShowSectionMenu(null);
        setShowPageMenu(null);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleCreateNotebook = async (e) => {
    e.preventDefault();
    if (newNotebookName.trim()) {
      try {
        await createNotebook(newNotebookName.trim());
        setNewNotebookName('');
        setShowNewNotebook(false);
      } catch (error) {
        console.error('Failed to create notebook:', error);
      }
    }
  };

  const handleCreateSection = async (e) => {
    e.preventDefault();
    if (newSectionName.trim()) {
      try {
        await createSection(newSectionName.trim());
        setNewSectionName('');
        setShowNewSection(false);
      } catch (error) {
        console.error('Failed to create section:', error);
      }
    }
  };

  const handleCreatePage = async () => {
    try {
      await createPage();
    } catch (error) {
      console.error('Failed to create page:', error);
    }
  };

  const handlePageDoubleClick = (page) => {
    setEditingPageId(page.id);
    setEditingPageTitle(page.title || '');
  editingOriginalTitleRef.current = page.title || '';
  editingCanceledRef.current = false;
  };

  const commitPageTitle = async () => {
    if (!editingPageId) return;
    const trimmed = editingPageTitle.trim();
    if (!trimmed) {
      // Revert empty to original
      setEditingPageTitle(editingOriginalTitleRef.current);
      setEditingPageId(null);
      return;
    }
    if (editingCanceledRef.current) {
      setEditingPageId(null);
      return; // user canceled
    }
    if (trimmed === editingOriginalTitleRef.current) {
      setEditingPageId(null); // no change
      return;
    }
    try {
      await updatePage(editingPageId, { title: trimmed });
    } catch (error) {
      console.error('Failed to update page title:', error);
    } finally {
      setEditingPageId(null);
      setEditingPageTitle('');
    }
  };

  const handlePageTitleSubmit = async (e) => {
    e.preventDefault();
    await commitPageTitle();
  };

  const handlePageTitleKeyDown = (e) => {
    if (e.key === 'Escape') {
      editingCanceledRef.current = true;
      setEditingPageId(null);
      setEditingPageTitle('');
    } else if (e.key === 'Enter') {
      e.preventDefault();
      commitPageTitle();
    }
  };

  // Drag and drop handlers for sections
  const handleSectionDragStart = (e, section) => {
    setDraggedSection(section);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleSectionDragOver = (e, index) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDragOverIndex(index);
  };

  const handleSectionDrop = async (e, dropIndex) => {
    e.preventDefault();
    if (!draggedSection) return;

    const sections = [...state.sections];
    const dragIndex = sections.findIndex(s => s.id === draggedSection.id);
    
    if (dragIndex === dropIndex) return;

    // Remove dragged section and insert at new position
    sections.splice(dragIndex, 1);
    sections.splice(dropIndex, 0, draggedSection);

    // Update order indices
    const reorderedSections = sections.map((section, index) => ({
      id: section.id,
      order_index: index
    }));

    try {
      await reorderSections(reorderedSections);
    } catch (error) {
      console.error('Failed to reorder sections:', error);
    }

    setDraggedSection(null);
    setDragOverIndex(null);
  };

  // Drag and drop handlers for pages
  const handlePageDragStart = (e, page) => {
    setDraggedPage(page);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handlePageDragOver = (e, index) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDragOverIndex(index);
  };

  const handlePageDrop = async (e, dropIndex) => {
    e.preventDefault();
    if (!draggedPage) return;

    const pages = [...state.pages];
    const dragIndex = pages.findIndex(p => p.id === draggedPage.id);
    
    if (dragIndex === dropIndex) return;

    // Remove dragged page and insert at new position
    pages.splice(dragIndex, 1);
    pages.splice(dropIndex, 0, draggedPage);

    // Update order indices
    const reorderedPages = pages.map((page, index) => ({
      id: page.id,
      order_index: index
    }));

    try {
      await reorderPages(reorderedPages);
    } catch (error) {
      console.error('Failed to reorder pages:', error);
    }

    setDraggedPage(null);
    setDragOverIndex(null);
  };

  const handleDeleteNotebook = async (id) => {
    setConfirmContext({ type: 'notebook', id, title: 'Delete notebook', payload: { message: 'Are you sure you want to delete this notebook? All sections and pages will be deleted.' } });
    setConfirmOpen(true);
  };

  const handleDeleteSection = async (id) => {
    setConfirmContext({ type: 'section', id, title: 'Delete section', payload: { message: 'Are you sure you want to delete this section? All pages will be deleted.' } });
    setConfirmOpen(true);
  };

  const handleDeletePage = async (id) => {
    setConfirmContext({ type: 'page', id, title: 'Delete page', payload: { message: 'Are you sure you want to delete this page?' } });
    setConfirmOpen(true);
  };

  const handleConfirmCancel = () => {
    setConfirmOpen(false);
    setConfirmContext({ type: null, id: null, title: '', payload: null });
  };

  const handleConfirm = async () => {
    const { type, id } = confirmContext;
    try {
      if (type === 'notebook') {
        await deleteNotebook(id);
      } else if (type === 'section') {
        await deleteSection(id);
        setShowSectionMenu(null);
      } else if (type === 'page') {
        await deletePage(id);
        setShowPageMenu(null);
      }
    } catch (error) {
      console.error('Failed to delete item:', error);
    } finally {
      handleConfirmCancel();
    }
  };

  const handleToggleSectionPin = async (section) => {
    try {
      await toggleSectionPin(section.id, !section.is_pinned);
      setShowSectionMenu(null);
    } catch (error) {
      console.error('Failed to toggle section pin:', error);
    }
  };

  const handleTogglePagePin = async (page) => {
    try {
      await togglePagePin(page.id, !page.is_pinned);
      setShowPageMenu(null);
    } catch (error) {
      console.error('Failed to toggle page pin:', error);
    }
  };

  const handleSetPagePassword = (pageId) => {
    setPasswordModalPageId(pageId);
    setIsSettingPassword(true);
    setShowPasswordModal(true);
    setShowPageMenu(null);
  };

  const handlePasswordModalSuccess = (pageData) => {
    if (isSettingPassword) {
      // Password was set or removed - refresh the page list
      if (state.currentSection) {
        loadPages(state.currentSection.id);
      }
      // If password was removed and page is current, clear session storage
      if (pageData && !pageData.is_password_protected) {
        sessionStorage.removeItem(`unlocked_${pageData.id}`);
      }
    } else if (pageData) {
      // If unlocking a page, navigate to it with the unlocked content
      selectPage(pageData.id, pageData);
    }
  };

  return (
    <>
      {/* Mobile overlay */}
      {state.sidebarOpen && (
        <div 
          className="drawer-overlay"
          onClick={() => dispatch({ type: 'SET_SIDEBAR_OPEN', payload: false })}
        />
      )}

      {/* Sidebar */}
      <div 
        ref={sidebarRef}
        className={`
        fixed lg:static inset-y-0 left-0 z-50 lg:z-auto
        ${state.sidebarOpen ? 'w-80' : 'w-12 lg:w-12'} 
        bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700
        sidebar-transition duration-300 ease-in-out
        ${state.sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-3 border-b border-gray-200 dark:border-gray-700">
            {state.sidebarOpen ? (
              <>
                <div className="flex items-center gap-2">
                  <svg 
                    width="32" 
                    height="32" 
                    viewBox="0 0 32 32" 
                    className="flex-shrink-0"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    {/* Notebook icon with modern design */}
                    <rect 
                      x="6" 
                      y="4" 
                      width="20" 
                      height="24" 
                      rx="2" 
                      fill="currentColor" 
                      className="text-blue-500 dark:text-blue-400"
                    />
                    <rect 
                      x="8" 
                      y="6" 
                      width="16" 
                      height="20" 
                      rx="1" 
                      fill="currentColor" 
                      className="text-white dark:text-gray-900"
                    />
                    {/* Lines representing text */}
                    <line 
                      x1="10" 
                      y1="10" 
                      x2="22" 
                      y2="10" 
                      stroke="currentColor" 
                      strokeWidth="1" 
                      className="text-gray-400 dark:text-gray-600"
                    />
                    <line 
                      x1="10" 
                      y1="13" 
                      x2="20" 
                      y2="13" 
                      stroke="currentColor" 
                      strokeWidth="1" 
                      className="text-gray-400 dark:text-gray-600"
                    />
                    <line 
                      x1="10" 
                      y1="16" 
                      x2="22" 
                      y2="16" 
                      stroke="currentColor" 
                      strokeWidth="1" 
                      className="text-gray-400 dark:text-gray-600"
                    />
                    <line 
                      x1="10" 
                      y1="19" 
                      x2="18" 
                      y2="19" 
                      stroke="currentColor" 
                      strokeWidth="1" 
                      className="text-gray-400 dark:text-gray-600"
                    />
                    {/* Pen/pencil accent */}
                    <circle 
                      cx="20" 
                      cy="22" 
                      r="2" 
                      fill="currentColor" 
                      className="text-orange-500 dark:text-orange-400"
                    />
                  </svg>
                  <h1 className="text-xl font-bold text-gray-900 dark:text-white">
                    OpenNotes
                  </h1>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => dispatch({ type: 'TOGGLE_CALENDAR' })}
                    className={`p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-800 ${state.calendarOpen ? 'bg-gray-100 dark:bg-gray-800' : ''}`}
                    title="Toggle Calendar"
                  >
                    📅
                  </button>
                  <button
                    onClick={() => { dispatch({ type: 'TOGGLE_TABBED' }); dispatch({ type: 'SET_CALENDAR_OPEN', payload: false }); }}
                    className={`p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-800 ${state.tabbedOpen ? 'bg-gray-100 dark:bg-gray-800' : ''}`}
                    title="Toggle Tabbed Notes"
                  >
                    🗂️
                  </button>
                  <button
                    onClick={() => {
                      try {
                        const env = typeof import.meta !== 'undefined' ? import.meta.env?.VITE_KEEP_URL : null;
                        const stored = (typeof window !== 'undefined') ? localStorage.getItem('keepBase') : null;
                        // Resolve a base candidate (may include port) from stored value, env, or window.location
                        const candidate = (stored && stored !== 'undefined' && stored !== 'null') ? stored : (env || (typeof window !== 'undefined' ? window.location.href : 'http://localhost'));
                        // Ensure we open using only protocol + hostname (no port), as requested
                        let url;
                        try {
                          url = new URL(candidate);
                        } catch (e) {
                          // If candidate is a path-only string, fallback to current location
                          url = (typeof window !== 'undefined') ? new URL(window.location.href) : new URL('http://localhost');
                        }
                        const originNoPort = `${url.protocol}//${url.hostname}`;
                        const target = originNoPort.replace(/\/$/, '') + '/keep';
                        window.open(target, '_blank');
                      } catch (err) {
                        console.error('Failed to open Keep page', err);
                      }
                    }}
                    className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-800"
                    title="Open Keep (separate tab)"
                  >
                    🔖
                  </button>
                  <button
                    onClick={() => dispatch({ type: 'SET_SIDEBAR_OPEN', payload: false })}
                    className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-800"
                    title="Collapse sidebar"
                  >
                    <ChevronLeft size={20} />
                  </button>
                </div>
              </>
            ) : (
              <button
                onClick={() => dispatch({ type: 'SET_SIDEBAR_OPEN', payload: true })}
                className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-800 w-full flex justify-center"
                title="Expand sidebar"
              >
                <Menu size={20} />
              </button>
            )}
          </div>

          {/* Content - only show when expanded */}
          {state.sidebarOpen && (
            <>
              {/* Notebook Selection */}
          <div className="p-3 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between mb-1">
                  <h2 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Notebooks
                  </h2>
                  <button
                    onClick={() => setShowNewNotebook(true)}
                    className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-800"
                    title="Add Notebook"
                  >
                    <Plus size={16} />
                  </button>
                </div>

            {showNewNotebook && (
              <form onSubmit={handleCreateNotebook} className="mb-2">
                <input
                  type="text"
                  value={newNotebookName}
                  onChange={(e) => setNewNotebookName(e.target.value)}
                  placeholder="Notebook name"
                  className="w-full px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-800"
                  autoFocus
                />
                <div className="flex gap-1 mt-1">
                  <button
                    type="submit"
                    className="px-2 py-1 text-xs bg-blue-500 text-white rounded hover:bg-blue-600"
                  >
                    Add
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowNewNotebook(false)}
                    className="px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded hover:bg-gray-100 dark:hover:bg-gray-800"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}

            <select
              value={state.currentNotebook?.id || ''}
              onChange={(e) => {
                const notebook = state.notebooks.find(nb => nb.id === parseInt(e.target.value));
                dispatch({ type: 'SET_CURRENT_NOTEBOOK', payload: notebook });
                dispatch({ type: 'SET_CALENDAR_OPEN', payload: false });
              }}
              className="w-full px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-800"
            >
              <option value="">Select a notebook</option>
              {state.notebooks.map(notebook => (
                <option key={notebook.id} value={notebook.id}>
                  {notebook.name}
                </option>
              ))}
            </select>
          </div>

          {/* Sections */}
          {state.currentNotebook && (
              <div className="p-3 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between mb-1">
                <h2 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Sections
                </h2>
                <button
                  onClick={() => setShowNewSection(true)}
                  className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-800"
                  title="Add Section"
                >
                  <Plus size={16} />
                </button>
              </div>

              {showNewSection && (
                <form onSubmit={handleCreateSection} className="mb-2">
                  <input
                    type="text"
                    value={newSectionName}
                    onChange={(e) => setNewSectionName(e.target.value)}
                    placeholder="Section name"
                    className="w-full px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-800"
                    autoFocus
                  />
                  <div className="flex gap-1 mt-1">
                    <button
                      type="submit"
                      className="px-2 py-1 text-xs bg-blue-500 text-white rounded hover:bg-blue-600"
                    >
                      Add
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowNewSection(false)}
                      className="px-2 py-1 text-xs border border-gray-300 dark:border-gray-600 rounded hover:bg-gray-100 dark:hover:bg-gray-800"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              )}

              <div className="flex flex-wrap gap-1">
                {state.sections.map((section, index) => (
                  <div
                    key={section.id}
                    draggable
                    onDragStart={(e) => handleSectionDragStart(e, section)}
                    onDragOver={(e) => handleSectionDragOver(e, index)}
                    onDrop={(e) => handleSectionDrop(e, index)}
                    className={`relative group flex items-center px-2 py-1 text-xs rounded border cursor-pointer transition-all ${
                      state.currentSection?.id === section.id
                        ? 'bg-blue-500 text-white border-blue-500'
                        : 'border-gray-300 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-800'
                    } ${dragOverIndex === index ? 'border-blue-400 border-2' : ''}`}
                  >
                    <GripVertical size={10} className="mr-1 opacity-50" />
                    {!!section.is_pinned && <Pin size={10} className="mr-1 text-yellow-500" />}
                    <Folder size={12} className="mr-1" />
                    <span 
                      onClick={() => { dispatch({ type: 'SET_CURRENT_SECTION', payload: section }); dispatch({ type: 'SET_CALENDAR_OPEN', payload: false }); }}
                      className="truncate flex-1"
                    >
                      {section.name}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowSectionMenu(showSectionMenu === section.id ? null : section.id);
                      }}
                      className="ml-1 p-0.5 rounded opacity-0 group-hover:opacity-100 hover:bg-gray-200 dark:hover:bg-gray-700 transition-opacity"
                    >
                      <MoreVertical size={10} />
                    </button>
                    
                    {/* Section Menu */}
                    {showSectionMenu === section.id && (
                      <div className="absolute top-full right-0 mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded shadow-lg z-10 min-w-32">
                        <button
                          onClick={() => handleToggleSectionPin(section)}
                          className="w-full text-left px-3 py-2 text-xs hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2"
                        >
                          <Pin size={12} />
                          {section.is_pinned ? 'Unpin' : 'Pin'}
                        </button>
                        <button
                          onClick={() => handleDeleteSection(section.id)}
                          className="w-full text-left px-3 py-2 text-xs hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2 text-red-600"
                        >
                          <Trash2 size={12} />
                          Delete
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Pages */}
          {state.currentSection && (
            <div className="flex-1 overflow-y-auto">
              <div className="p-3">
                {/* Sticky header so user can always add/select pages while scrolling */}
                <div className="sticky top-0 -mx-3 px-3 py-2 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 z-20">
                    <div className="flex items-center justify-between mb-2">
                      <h2 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                        Pages
                      </h2>
                      <div className="flex items-center gap-2">
                        <input
                          type="search"
                          value={pageSearch}
                          onChange={(e) => setPageSearch(e.target.value)}
                          placeholder="Search pages..."
                          className="px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-800"
                          aria-label="Search pages"
                        />
                        {pageSearch && (
                          <button
                            onClick={() => setPageSearch('')}
                            className="px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-800"
                            title="Clear search"
                          >
                            <X size={14} />
                          </button>
                        )}
                        <button
                          onClick={handleCreatePage}
                          className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-800"
                          title="Add Page"
                        >
                          <Plus size={16} />
                        </button>
                      </div>
                    </div>
                </div>

                <div className="mt-1 space-y-1">
                  {filteredPages.map((page, index) => (
                    <div
                      key={page.id}
                      draggable={pageSearch === ''}
                      onDragStart={pageSearch === '' ? (e) => handlePageDragStart(e, page) : undefined}
                      onDragOver={pageSearch === '' ? (e) => handlePageDragOver(e, index) : undefined}
                      onDrop={pageSearch === '' ? (e) => handlePageDrop(e, index) : undefined}
                      className={`relative group w-full text-left px-2 py-2 text-sm rounded border cursor-pointer transition-all ${
                        state.currentPage?.id === page.id
                          ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800'
                          : 'border-transparent hover:bg-gray-100 dark:hover:bg-gray-800'
                      } ${dragOverIndex === index ? 'border-blue-400 border-2' : ''}`}
                    >
                      {editingPageId === page.id ? (
                        <form onSubmit={handlePageTitleSubmit} className="flex items-center">
                          <FileText size={14} className="mr-2 text-gray-400 flex-shrink-0" />
                          <input
                            type="text"
                            value={editingPageTitle}
                            onChange={(e) => setEditingPageTitle(e.target.value)}
                            onKeyDown={handlePageTitleKeyDown}
                            onBlur={commitPageTitle}
                            className="flex-1 bg-transparent border-none outline-none text-sm"
                            autoFocus
                          />
                        </form>
                      ) : (
                        <div className="flex items-start gap-2">
                          <div className="flex items-center gap-1 flex-shrink-0 mt-0.5 [&>span.numeric-artifact]:hidden">
                            <GripVertical size={12} className="opacity-50" />
                            {!!page.is_pinned && <Pin size={12} className="text-yellow-500" />}
                            {!!page.is_password_protected && <Lock size={12} className="text-red-500" />}
                            <FileText size={14} className="text-gray-400" />
                          </div>
                          <div 
                            className="flex-1 min-w-0"
                            onClick={() => { selectPage(page); dispatch({ type: 'SET_CALENDAR_OPEN', payload: false }); }}
                            onDoubleClick={() => handlePageDoubleClick(page)}
                          >
                            <div className="flex items-center justify-between">
                              <span className="truncate font-medium">{page.title || 'Untitled Page'}</span>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setShowPageMenu(showPageMenu === page.id ? null : page.id);
                                }}
                                className="p-1 rounded opacity-0 group-hover:opacity-100 hover:bg-gray-200 dark:hover:bg-gray-700 transition-opacity flex-shrink-0"
                              >
                                <MoreVertical size={12} />
                              </button>
                            </div>
                            <div className="text-xs text-gray-500 mt-1">
                              {new Date(page.updated_at).toLocaleDateString()}
                            </div>
                          </div>
                          
                          {/* Page Menu */}
                          {showPageMenu === page.id && (
                            <div className="absolute top-full right-2 mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded shadow-lg z-10 min-w-32">
                              <button
                                onClick={() => handleTogglePagePin(page)}
                                className="w-full text-left px-3 py-2 text-xs hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2"
                              >
                                <Pin size={12} />
                                {page.is_pinned ? 'Unpin' : 'Pin'}
                              </button>
                              <button
                                onClick={() => handleSetPagePassword(page.id)}
                                className="w-full text-left px-3 py-2 text-xs hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2"
                              >
                                <Shield size={12} />
                                {page.is_password_protected ? 'Change Password' : 'Set Password'}
                              </button>
                              <button
                                onClick={() => handleDeletePage(page.id)}
                                className="w-full text-left px-3 py-2 text-xs hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2 text-red-600"
                              >
                                <Trash2 size={12} />
                                Delete
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Empty State */}
          {!state.currentNotebook && (
            <div className="flex-1 flex items-center justify-center p-4">
              <div className="text-center text-gray-500 dark:text-gray-400">
                <BookOpen size={48} className="mx-auto mb-2 opacity-50" />
                <p className="text-sm">Create or select a notebook to get started</p>
              </div>
            </div>
          )}
            </>
          )}
        </div>
      </div>

      {/* Password Modal */}
      <PagePasswordModal
        isOpen={showPasswordModal}
        onClose={() => {
          setShowPasswordModal(false);
          setPasswordModalPageId(null);
          setIsSettingPassword(false);
        }}
        pageId={passwordModalPageId}
        onSuccess={handlePasswordModalSuccess}
        isSettingPassword={isSettingPassword}
      />
      {/* Responsive Confirm Modal */}
      <ConfirmModal
        isOpen={confirmOpen}
        title={confirmContext.title}
        message={confirmContext.payload?.message}
        onCancel={handleConfirmCancel}
        onConfirm={handleConfirm}
        confirmLabel="Delete"
        cancelLabel="Cancel"
      />
    </>
  );
};

export default Sidebar;
