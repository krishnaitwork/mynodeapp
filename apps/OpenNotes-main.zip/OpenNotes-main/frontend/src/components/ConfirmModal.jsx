import React from 'react';

const ConfirmModal = ({ isOpen, title = 'Confirm', message, onCancel, onConfirm, confirmLabel = 'Delete', cancelLabel = 'Cancel' }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onCancel} />

      <div className="relative w-full max-w-md sm:max-w-lg bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
        <div className="p-4 sm:p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{title}</h3>
          {message && (
            <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">{message}</p>
          )}
        </div>

        <div className="px-4 pb-4 sm:px-6 sm:pb-6">
          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <button
              onClick={onCancel}
              className="w-full sm:w-auto px-4 py-2 rounded border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-700 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-600"
            >
              {cancelLabel}
            </button>
            <button
              onClick={onConfirm}
              className="w-full sm:w-auto px-4 py-2 rounded bg-red-600 text-sm text-white hover:bg-red-700"
            >
              {confirmLabel}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConfirmModal;
