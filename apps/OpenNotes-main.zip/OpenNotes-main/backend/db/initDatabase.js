const Database = require('better-sqlite3');
const path = require('path');

// Create or connect to SQLite database (DB file stored at backend root)
const db = new Database(path.join(__dirname, '..', 'opennotes.db'));

// Initialize database schema
function initDatabase() {
  // Create notebooks table
  db.exec(`
    CREATE TABLE IF NOT EXISTS notebooks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Create sections table
  db.exec(`
    CREATE TABLE IF NOT EXISTS sections (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      notebook_id INTEGER,
      name TEXT NOT NULL,
      order_index INTEGER DEFAULT 0,
      is_pinned BOOLEAN DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (notebook_id) REFERENCES notebooks(id) ON DELETE CASCADE
    )
  `);

  // Create pages table
  db.exec(`
    CREATE TABLE IF NOT EXISTS pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      section_id INTEGER,
      title TEXT DEFAULT 'Untitled Page',
      content TEXT DEFAULT '',
      order_index INTEGER DEFAULT 0,
      is_pinned BOOLEAN DEFAULT 0,
      is_password_protected BOOLEAN DEFAULT 0,
      password_hash TEXT DEFAULT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (section_id) REFERENCES sections(id) ON DELETE CASCADE
    )
  `);

  // Calendar tasks table (shared DB) - stores simple todo items/notes per day
  db.exec(`
    CREATE TABLE IF NOT EXISTS calendar_tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      notes TEXT DEFAULT '',
      due_date DATE NOT NULL,
      is_completed BOOLEAN DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Tabbed notes table - stores editor tabs saved to the backend
  db.exec(`
    CREATE TABLE IF NOT EXISTS tabbed_notes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT DEFAULT 'Untitled',
      content TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Create users table for authentication
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      salt TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Create sessions table for login sessions
  db.exec(`
    CREATE TABLE IF NOT EXISTS sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      session_token TEXT UNIQUE NOT NULL,
      expires_at DATETIME NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )
  `);

  // Create sample data if tables are empty
  const notebookCount = db.prepare('SELECT COUNT(*) as count FROM notebooks').get().count;
  if (notebookCount === 0) {
    const insertNotebook = db.prepare('INSERT INTO notebooks (name) VALUES (?)');
    const insertSection = db.prepare('INSERT INTO sections (notebook_id, name, order_index) VALUES (?, ?, ?)');
    const insertPage = db.prepare('INSERT INTO pages (section_id, title, content, order_index) VALUES (?, ?, ?, ?)');

    // Create sample notebook
    const notebookResult = insertNotebook.run('My First Notebook');
    const notebookId = notebookResult.lastInsertRowid;

    // Create sample sections
    const section1 = insertSection.run(notebookId, 'General Notes', 0);
    const section2 = insertSection.run(notebookId, 'Ideas', 1);

    // Create sample pages
    insertPage.run(section1.lastInsertRowid, 'Welcome to OpenNotes', 
      JSON.stringify({
        type: 'doc',
        content: [
          {
            type: 'heading',
            attrs: { level: 1 },
            content: [{ type: 'text', text: 'Welcome to OpenNotes!' }]
          },
          {
            type: 'paragraph',
            content: [
              { type: 'text', text: 'This is your first page. You can edit this content using the rich text editor.' }
            ]
          }
        ]
      }), 0
    );

    insertPage.run(section2.lastInsertRowid, 'Project Ideas', 
      JSON.stringify({
        type: 'doc',
        content: [
          {
            type: 'heading',
            attrs: { level: 2 },
            content: [{ type: 'text', text: 'Project Ideas' }]
          },
          {
            type: 'bulletList',
            content: [
              {
                type: 'listItem',
                content: [
                  {
                    type: 'paragraph',
                    content: [{ type: 'text', text: 'Add more features to OpenNotes' }]
                  }
                ]
              }
            ]
          }
        ]
      }), 0
    );

    console.log('Sample data created successfully!');
  } else {
    console.log('Existing data detected; no schema migration (ALTER) needed because CREATE IF NOT EXISTS includes all columns.');
  }

  console.log('Database initialized successfully!');
}

if (require.main === module) {
  initDatabase();
}

module.exports = { db, initDatabase };
