const path = require('path');
const Database = require('better-sqlite3');
const dbPath = path.join(__dirname, '..', 'opennotes.db');
const db = new Database(dbPath);

function createTab(title = 'Untitled', content = '') {
  const now = new Date().toISOString();
  const stmt = db.prepare('INSERT INTO tabbed_notes (title, content, created_at, updated_at) VALUES (?, ?, ?, ?)');
  const info = stmt.run(title, content, now, now);
  return { id: info.lastInsertRowid, title, content, createdAt: now, updatedAt: now };
}

function getTab(id) {
  return db.prepare('SELECT id, title, content, created_at as createdAt, updated_at as updatedAt FROM tabbed_notes WHERE id = ?').get(id);
}

function listTabs() {
  return db.prepare('SELECT id, title, content, created_at as createdAt, updated_at as updatedAt FROM tabbed_notes ORDER BY updated_at DESC').all();
}

function updateTab(id, { title, content }) {
  const now = new Date().toISOString();
  db.prepare('UPDATE tabbed_notes SET title = ?, content = ?, updated_at = ? WHERE id = ?').run(title, content, now, id);
  return getTab(id);
}

function deleteTab(id) {
  db.prepare('DELETE FROM tabbed_notes WHERE id = ?').run(id);
  return { deleted: true };
}

module.exports = {
  createTab,
  getTab,
  listTabs,
  updateTab,
  deleteTab,
};
