const { db } = require('./initDatabase');
const dayjs = require('dayjs');

// CRUD helpers for calendar tasks
function createTask({ title, notes = '', due_date }) {
  const stmt = db.prepare('INSERT INTO calendar_tasks (title, notes, due_date) VALUES (?, ?, ?)');
  const res = stmt.run(title, notes, due_date);
  return getTaskById(res.lastInsertRowid);
}

function getTaskById(id) {
  return db.prepare('SELECT * FROM calendar_tasks WHERE id = ?').get(id);
}

function listTasks({ fromDate, toDate } = {}) {
  if (fromDate && toDate) {
    return db.prepare('SELECT * FROM calendar_tasks WHERE due_date BETWEEN ? AND ? ORDER BY due_date, id').all(fromDate, toDate);
  }
  if (fromDate) {
    return db.prepare('SELECT * FROM calendar_tasks WHERE due_date >= ? ORDER BY due_date, id').all(fromDate);
  }
  return db.prepare('SELECT * FROM calendar_tasks ORDER BY due_date, id').all();
}

function updateTask(id, fields = {}) {
  const allowed = ['title', 'notes', 'due_date', 'is_completed'];
  const setClauses = [];
  const values = [];
  allowed.forEach(key => {
    if (key in fields) {
      setClauses.push(`${key} = ?`);
      values.push(fields[key]);
    }
  });
  if (setClauses.length === 0) return getTaskById(id);
  values.push(id);
  const sql = `UPDATE calendar_tasks SET ${setClauses.join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`;
  db.prepare(sql).run(...values);
  return getTaskById(id);
}

function deleteTask(id) {
  db.prepare('DELETE FROM calendar_tasks WHERE id = ?').run(id);
  return { success: true };
}

// Rollover: move incomplete tasks where due_date <= today to next day
function rolloverIncompleteToNextDay(today = dayjs().format('YYYY-MM-DD')) {
  const incomplete = db.prepare('SELECT * FROM calendar_tasks WHERE is_completed = 0 AND due_date <= ?').all(today);
  if (!incomplete.length) return { moved: 0 };
  const nextDay = dayjs(today).add(1, 'day').format('YYYY-MM-DD');
  const update = db.prepare('UPDATE calendar_tasks SET due_date = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
  const movedCount = incomplete.reduce((acc, item) => {
    update.run(nextDay, item.id);
    return acc + 1;
  }, 0);
  return { moved: movedCount };
}

// Catch-up for servers that were down: move incomplete tasks with due_date < today
// forward to today so they are visible on the current day when the server starts.
function catchupIncompleteToToday(targetDate = dayjs().format('YYYY-MM-DD')) {
  const overdue = db.prepare('SELECT * FROM calendar_tasks WHERE is_completed = 0 AND due_date < ?').all(targetDate);
  if (!overdue.length) return { moved: 0 };
  const update = db.prepare('UPDATE calendar_tasks SET due_date = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?');
  const movedCount = overdue.reduce((acc, item) => {
    update.run(targetDate, item.id);
    return acc + 1;
  }, 0);
  return { moved: movedCount };
}

module.exports = {
  createTask,
  getTaskById,
  listTasks,
  updateTask,
  deleteTask,
  rolloverIncompleteToNextDay
  , catchupIncompleteToToday
};
