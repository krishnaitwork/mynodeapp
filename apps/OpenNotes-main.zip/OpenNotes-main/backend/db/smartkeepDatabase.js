const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// DB file stored at backend root for consistency with other assets
const DB_PATH = path.join(__dirname, '..', 'smartkeep.db');

let smartkeepDb;

const initSmartKeepDatabase = () => {
  return new Promise((resolve, reject) => {
    smartkeepDb = new sqlite3.Database(DB_PATH, (err) => {
      if (err) {
        console.error('Error opening SmartKeep database:', err);
        reject(err);
        return;
      }
      console.log('📁 Connected to SmartKeep SQLite database');
      
      // Create notes table with schema matching the original OneNote.html
      const createNotesTable = `
        CREATE TABLE IF NOT EXISTS notes (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT,
          content TEXT NOT NULL,
          category TEXT DEFAULT 'Work',
          pinned INTEGER DEFAULT 0,
          is_password INTEGER DEFAULT 0,
          archived INTEGER DEFAULT 0,
          CreatedDate TEXT DEFAULT CURRENT_TIMESTAMP,
          LastModifiedDate TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `;
      
      smartkeepDb.run(createNotesTable, (err) => {
        if (err) {
          console.error('Error creating SmartKeep notes table:', err);
          reject(err);
          return;
        }
        console.log('✅ SmartKeep notes table created/verified');
        
        // Create indexes for better performance
        const indexes = [
          'CREATE INDEX IF NOT EXISTS idx_notes_category ON notes(category)',
          'CREATE INDEX IF NOT EXISTS idx_notes_pinned ON notes(pinned)',
          'CREATE INDEX IF NOT EXISTS idx_notes_archived ON notes(archived)',
          'CREATE INDEX IF NOT EXISTS idx_notes_created_date ON notes(CreatedDate)'
        ];
        
        let indexCount = 0;
        indexes.forEach((indexSQL) => {
          smartkeepDb.run(indexSQL, (err) => {
            if (err) {
              console.error('Error creating SmartKeep index:', err);
            }
            indexCount++;
            if (indexCount === indexes.length) {
              console.log('✅ SmartKeep database indexes created/verified');
              resolve();
            }
          });
        });
      });
    });
  });
};

const getSmartKeepDatabase = () => {
  if (!smartkeepDb) {
    throw new Error('SmartKeep database not initialized');
  }
  return smartkeepDb;
};

const closeSmartKeepDatabase = () => {
  return new Promise((resolve) => {
    if (smartkeepDb) {
      smartkeepDb.close((err) => {
        if (err) {
          console.error('Error closing SmartKeep database:', err);
        } else {
          console.log('📁 SmartKeep database connection closed');
        }
        resolve();
      });
    } else {
      resolve();
    }
  });
};

module.exports = {
  initSmartKeepDatabase,
  getSmartKeepDatabase,
  closeSmartKeepDatabase
};
