# OpenNotes Common Server

This is a unified backend server that serves multiple projects:

## Projects Supported

### 1. OpenNotes (Original)
- **Endpoints**: `/api/*` (notebooks, sections, pages, auth)
- **Database**: `opennotes.db` (SQLite)
- **Features**: Note-taking with notebooks/sections, authentication, password protection

### 2. SmartKeep (Google Keep Clone)
- **Endpoints**: `/api/smartkeep/notes/*`
- **Database**: `smartkeep.db` (SQLite)
- **Features**: Quick notes with categories, pin/archive, export/import

## Server Structure

```
backend/
├── server.js                 # Main server file (clean & modular)
├── authService.js           # Authentication service
├── db/                      # Database initialization modules
│   ├── initDatabase.js      # OpenNotes database initialization
│   └── smartkeepDatabase.js # SmartKeep database initialization
│
├── routes/                  # Modular route files
│   ├── authRoutes.js        # Authentication routes
│   ├── notebookRoutes.js    # Notebook management routes
│   ├── sectionRoutes.js     # Section management routes
│   ├── pageRoutes.js        # Page management routes
│   ├── searchRoutes.js      # Search functionality routes
│   └── smartkeepRoutes.js   # SmartKeep routes
│
├── databases/               # Database files
│   ├── opennotes.db        # OpenNotes database
│   └── smartkeep.db        # SmartKeep database
│
└── test-apis.js            # API testing script
```

## API Endpoints

### OpenNotes Routes (`/api/`)

#### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/verify` - Verify token
- `GET /api/auth/me` - Get current user

#### Notebooks
- `GET /api/notebooks` - Get all notebooks
- `POST /api/notebooks` - Create notebook
- `PUT /api/notebooks/:id` - Update notebook
- `DELETE /api/notebooks/:id` - Delete notebook

#### Sections
- `GET /api/notebooks/:id/sections` - Get sections in notebook
- `POST /api/sections` - Create section
- `PUT /api/sections/:id` - Update section
- `DELETE /api/sections/:id` - Delete section

#### Pages
- `GET /api/sections/:id/pages` - Get pages in section
- `GET /api/pages/:id` - Get specific page
- `POST /api/pages` - Create page
- `PUT /api/pages/:id` - Update page
- `DELETE /api/pages/:id` - Delete page
- `POST /api/pages/:id/set-password` - Set page password
- `POST /api/pages/:id/remove-password` - Remove page password
- `POST /api/pages/:id/unlock` - Unlock protected page

#### Search & Utility
- `GET /api/search` - Search pages
- `GET /api/health` - Health check

### SmartKeep Routes (`/api/smartkeep/notes/`)

#### Notes Management
- `GET /api/smartkeep/notes` - Get all notes (with filtering)
- `GET /api/smartkeep/notes/:id` - Get specific note
- `POST /api/smartkeep/notes` - Create note
- `PUT /api/smartkeep/notes/:id` - Update note
- `DELETE /api/smartkeep/notes/:id` - Delete note

#### Note Actions
- `PATCH /api/smartkeep/notes/:id/pin` - Toggle pin status
- `PATCH /api/smartkeep/notes/:id/archive` - Toggle archive status

#### Categories & Data
- `GET /api/smartkeep/notes/categories` - Get all categories
- `GET /api/smartkeep/notes/export` - Export all notes
- `POST /api/smartkeep/notes/import` - Import notes

## Query Parameters

### SmartKeep Notes Filtering
- `search` - Search in title, content, category
- `category` - Filter by category
- `archived` - Show archived notes (true/false)
- `pinned` - Show pinned notes (true/false)

Example: `GET /api/smartkeep/notes?search=password&category=Work&pinned=true`

## Database Schemas

### OpenNotes Schema
```sql
-- Users table
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  salt TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Notebooks table
CREATE TABLE notebooks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Sections table
CREATE TABLE sections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  notebook_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  is_pinned INTEGER DEFAULT 0,
  order_index INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (notebook_id) REFERENCES notebooks (id) ON DELETE CASCADE
);

-- Pages table
CREATE TABLE pages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  section_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  content TEXT,
  is_pinned INTEGER DEFAULT 0,
  is_password_protected INTEGER DEFAULT 0,
  password_hash TEXT,
  order_index INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (section_id) REFERENCES sections (id) ON DELETE CASCADE
);
```

### SmartKeep Schema
```sql
-- Notes table
CREATE TABLE notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT,
  content TEXT NOT NULL,
  category TEXT DEFAULT 'Work',
  pinned INTEGER DEFAULT 0,
  is_password INTEGER DEFAULT 0,
  archived INTEGER DEFAULT 0,
  CreatedDate TEXT DEFAULT CURRENT_TIMESTAMP,
  LastModifiedDate TEXT DEFAULT CURRENT_TIMESTAMP
);
```

## Running the Server

### Prerequisites
```bash
npm install express cors sqlite3 bcrypt jsonwebtoken helmet
```

### Start Server
```bash
cd backend
node server.js
```

The server will run on port 5000 and initialize both databases automatically.

### Server Output
```
📁 Connected to SQLite database (OpenNotes)
✅ Database initialized successfully
📁 Connected to SmartKeep SQLite database
✅ SmartKeep notes table created/verified
✅ SmartKeep database indexes created/verified
OpenNotes backend server running on port 5000
Health check: http://localhost:5000/api/health
SmartKeep API: http://localhost:5000/api/smartkeep/notes
```

## Client Configuration

### OpenNotes Client
- No changes needed, uses default `/api/` endpoints

### SmartKeep Client
Update `client/src/services/api.js`:
```javascript
const BASE_URL = 'http://localhost:5000/api/smartkeep';
```

## Environment Variables

Create `.env` file in backend directory:
```env
PORT=5000
NODE_ENV=development
JWT_SECRET=your-secret-key-here
CLIENT_URL=http://localhost:5173
```

## Adding New Projects

To add a new project to this common server:

### 1. Create Database Module
Create `[project]Database.js`:
```javascript
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const DB_PATH = path.join(__dirname, '[project].db');
let [project]Db;

const init[Project]Database = () => {
  return new Promise((resolve, reject) => {
    [project]Db = new sqlite3.Database(DB_PATH, (err) => {
      if (err) {
        reject(err);
        return;
      }
      console.log('📁 Connected to [Project] SQLite database');
      // Initialize tables here
      resolve();
    });
  });
};

const get[Project]Database = () => {
  if (![project]Db) {
    throw new Error('[Project] database not initialized');
  }
  return [project]Db;
};

module.exports = {
  init[Project]Database,
  get[Project]Database
};
```

### 2. Create Routes Module
Create `[project]Routes.js`:
```javascript
const express = require('express');
const { get[Project]Database } = require('./[project]Database');

const router = express.Router();

// Add your routes here
router.get('/', (req, res) => {
  // Route implementation
});

module.exports = router;
```

### 3. Update Main Server
Add to `server.js`:
```javascript
// Import modules
const { init[Project]Database } = require('./db/[project]Database');
const [project]Routes = require('./routes/[project]Routes');

// Initialize database
init[Project]Database();

// Mount routes
app.use('/api/[project]', [project]Routes);
```

### 4. Update Package.json
Add any new dependencies to `package.json`.

## Modular Architecture Benefits

### ✅ **Clean Separation**
- Each project has its own database and routes
- Server.js remains clean and focused on configuration
- Easy to maintain and debug individual components

### ✅ **Easy Expansion**
- Adding new projects requires minimal changes to core server
- Consistent pattern for all projects
- No route conflicts or namespace pollution

### ✅ **Independent Development**
- Teams can work on different projects simultaneously
- Routes are self-contained and testable
- Database schemas are isolated

### ✅ **Scalable Design**
- Can easily split into microservices later
- Routes can be moved to separate servers if needed
- Shared utilities and middleware

## Features

### Security
- CORS enabled for multiple origins
- Request/response logging
- Error handling middleware
- JWT authentication for OpenNotes
- Password hashing with bcrypt

### Database Management
- Automatic database initialization
- Graceful shutdown handling
- Transaction support for imports
- Indexed tables for performance

### Development Features
- Health check endpoints
- Comprehensive error logging
- Hot reload support
- Environment-based configuration

## Port Configuration

- **Server**: 5000 (default)
- **OpenNotes Client**: 3000
- **SmartKeep Client**: 5173

Ensure your client applications point to the correct server port (5000) for API calls.
