const express = require('express');
const cors = require('cors');

// Database initializations (updated paths after refactor)
const { initDatabase } = require('./db/initDatabase');
const { initSmartKeepDatabase, closeSmartKeepDatabase } = require('./db/smartkeepDatabase');

// Route imports (updated paths after refactor)
const authRoutes = require('./routes/authRoutes');
const notebookRoutes = require('./routes/notebookRoutes');
const sectionRoutes = require('./routes/sectionRoutes');
const pageRoutes = require('./routes/pageRoutes');
const searchRoutes = require('./routes/searchRoutes');
const smartkeepRoutes = require('./routes/smartkeepRoutes');
const calendarRoutes = require('./routes/calendarRoutes');
const tabbedRoutes = require('./routes/tabbedRoutes');
const { rolloverIncompleteToNextDay } = require('./db/calendarDatabase');
const { catchupIncompleteToToday } = require('./db/calendarDatabase');
const cron = require('node-cron');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Initialize databases
initDatabase();
initSmartKeepDatabase();

// ============ ROUTE MOUNTING ============

// OpenNotes Routes
app.use('/api/auth', authRoutes);
app.use('/api/notebooks', notebookRoutes);
app.use('/api/sections', sectionRoutes);
app.use('/api/pages', pageRoutes);
app.use('/api/search', searchRoutes);

// SmartKeep Routes
app.use('/api/smartkeep/notes', smartkeepRoutes);

// Calendar Routes
app.use('/api/calendar', calendarRoutes);

// Tabbed notes routes
app.use('/api/tabbed-notes', tabbedRoutes);

// ============ UTILITY ROUTES ============

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    services: {
      opennotes: 'running',
      smartkeep: 'running'
    }
  });
});

// API info endpoint
app.get('/api', (req, res) => {
  res.json({
    name: 'OpenNotes Common Backend Server',
    version: '1.0.0',
    description: 'Unified backend serving OpenNotes and SmartKeep projects',
    endpoints: {
      opennotes: {
        auth: '/api/auth',
        notebooks: '/api/notebooks',
        sections: '/api/sections', 
        pages: '/api/pages',
        search: '/api/search'
      },
      smartkeep: {
        notes: '/api/smartkeep/notes'
      },
      utility: {
        health: '/api/health',
        info: '/api'
      }
    }
  });
});

// ============ ERROR HANDLING ============

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Server error:', error);
  res.status(500).json({ error: 'Internal server error' });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({ 
    error: 'Route not found',
    availableEndpoints: '/api'
  });
});

// ============ SERVER STARTUP ============

app.listen(PORT, () => {
  console.log('🚀 OpenNotes Common Backend Server');
  console.log(`📡 Server running on port ${PORT}`);
  console.log('');
  console.log('📋 Available Services:');
  console.log(`   ✅ OpenNotes API: http://localhost:${PORT}/api/`);
  console.log(`   ✅ SmartKeep API: http://localhost:${PORT}/api/smartkeep/notes/`);
  console.log(`   ✅ Health Check: http://localhost:${PORT}/api/health`);
  console.log(`   📖 API Info: http://localhost:${PORT}/api`);
  console.log('');
});

// Optional daily rollover job (runs at 00:05 server local time)
if (process.env.BACKEND_ENABLE_ROLLOVER !== 'false') {
  // Run a catch-up pass now in case the server was offline at the scheduled time.
  if (process.env.BACKEND_ENABLE_ROLLOVER_CATCHUP !== 'false') {
    try {
      console.log('Running startup calendar catch-up...');
      const res = catchupIncompleteToToday();
      console.log(`Startup catch-up moved ${res.moved} tasks`);
    } catch (err) {
      console.warn('Startup calendar catch-up failed:', err);
    }
  }
  try {
    cron.schedule('5 0 * * *', () => {
      console.log('Running daily calendar rollover...');
      const res = rolloverIncompleteToNextDay();
      console.log(`Rollover moved ${res.moved} tasks`);
    }, { scheduled: true, timezone: process.env.SERVER_TIMEZONE || 'UTC' });
    console.log('✅ Calendar rollover scheduled (daily at 00:05 server time).');
  } catch (err) {
    console.warn('Failed to schedule calendar rollover:', err);
  }
}

// ============ GRACEFUL SHUTDOWN ============

const gracefulShutdown = async (signal) => {
  console.log(`\n🛑 Received ${signal}. Shutting down gracefully...`);
  
  try {
    await closeSmartKeepDatabase();
    console.log('✅ All databases closed successfully');
    process.exit(0);
  } catch (error) {
    console.error('❌ Error during shutdown:', error);
    process.exit(1);
  }
};

process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('💥 Uncaught Exception:', error);
  gracefulShutdown('uncaughtException');
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('💥 Unhandled Rejection at:', promise, 'reason:', reason);
  gracefulShutdown('unhandledRejection');
});

module.exports = app;
