const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');

// Configuration
const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-in-production';
const SALT_ROUNDS = 12;

class AuthService {
  // Generate a random salt
  static generateSalt() {
    return crypto.randomBytes(32).toString('hex');
  }

  // Hash password with salt
  static async hashPassword(password, salt = null) {
    if (!salt) {
      salt = this.generateSalt();
    }
    const hash = await bcrypt.hash(password + salt, SALT_ROUNDS);
    return { hash, salt };
  }

  // Verify password
  static async verifyPassword(password, hash, salt) {
    return await bcrypt.compare(password + salt, hash);
  }

  // Generate JWT token
  static generateToken(userId, username) {
    return jwt.sign(
      { userId, username },
      JWT_SECRET,
      { expiresIn: '24h' }
    );
  }

  // Verify JWT token
  static verifyToken(token) {
    try {
      return jwt.verify(token, JWT_SECRET);
    } catch (error) {
      return null;
    }
  }

  // Generate session token
  static generateSessionToken() {
    return crypto.randomBytes(64).toString('hex');
  }

  // Hash password for page protection (simpler)
  static async hashPagePassword(password) {
    return await bcrypt.hash(password, 10);
  }

  // Verify page password
  static async verifyPagePassword(password, hash) {
    return await bcrypt.compare(password, hash);
  }
}

// Middleware to authenticate requests
const authenticateUser = (req, res, next) => {
  const token = req.header('Authorization')?.replace('Bearer ', '');
  
  if (!token) {
    return res.status(401).json({ error: 'Access denied. No token provided.' });
  }

  const decoded = AuthService.verifyToken(token);
  if (!decoded) {
    return res.status(401).json({ error: 'Invalid token.' });
  }

  req.user = decoded;
  next();
};

// Middleware to optionally authenticate (for public/private content)
const optionalAuth = (req, res, next) => {
  const token = req.header('Authorization')?.replace('Bearer ', '');
  
  if (token) {
    const decoded = AuthService.verifyToken(token);
    if (decoded) {
      req.user = decoded;
    }
  }
  
  next();
};

module.exports = {
  AuthService,
  authenticateUser,
  optionalAuth,
  JWT_SECRET
};
