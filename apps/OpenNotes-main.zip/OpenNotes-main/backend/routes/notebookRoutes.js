const express = require('express');
const { db } = require('../db/initDatabase');

const router = express.Router();

// Get all notebooks
router.get('/', (req, res) => {
  try {
    const notebooks = db.prepare('SELECT * FROM notebooks ORDER BY created_at DESC').all();
    res.json(notebooks);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create new notebook
router.post('/', (req, res) => {
  try {
    const { name } = req.body;
    if (!name) {
      return res.status(400).json({ error: 'Notebook name is required' });
    }
    
    const result = db.prepare('INSERT INTO notebooks (name) VALUES (?)').run(name);
    const notebook = db.prepare('SELECT * FROM notebooks WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(notebook);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update notebook
router.put('/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { name } = req.body;
    
    db.prepare('UPDATE notebooks SET name = ? WHERE id = ?').run(name, id);
    const notebook = db.prepare('SELECT * FROM notebooks WHERE id = ?').get(id);
    res.json(notebook);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete notebook
router.delete('/:id', (req, res) => {
  try {
    const { id } = req.params;
    db.prepare('DELETE FROM notebooks WHERE id = ?').run(id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get sections in notebook
router.get('/:id/sections', (req, res) => {
  try {
    const { id } = req.params;
    const sections = db.prepare(`
      SELECT * FROM sections 
      WHERE notebook_id = ? 
      ORDER BY is_pinned DESC, order_index ASC, created_at ASC
    `).all(id);
    res.json(sections);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Bulk reorder sections
router.put('/:id/sections/reorder', (req, res) => {
  try {
    const { id } = req.params;
    const { sections } = req.body; // Array of {id, order_index}
    
    const transaction = db.transaction((sections) => {
      for (const section of sections) {
        db.prepare('UPDATE sections SET order_index = ? WHERE id = ? AND notebook_id = ?')
          .run(section.order_index, section.id, id);
      }
    });
    
    transaction(sections);
    
    const updatedSections = db.prepare(`
      SELECT * FROM sections 
      WHERE notebook_id = ? 
      ORDER BY is_pinned DESC, order_index ASC, created_at ASC
    `).all(id);
    
    res.json(updatedSections);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
