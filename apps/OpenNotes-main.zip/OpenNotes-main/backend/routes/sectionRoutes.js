const express = require('express');
const { db } = require('../db/initDatabase');

const router = express.Router();

// Create new section
router.post('/', (req, res) => {
  try {
    const { notebook_id, name } = req.body;
    if (!notebook_id || !name) {
      return res.status(400).json({ error: 'Notebook ID and section name are required' });
    }
    
    // Get the next order index
    const maxOrder = db.prepare('SELECT MAX(order_index) as max_order FROM sections WHERE notebook_id = ?').get(notebook_id);
    const nextOrder = (maxOrder.max_order || 0) + 1;
    
    const result = db.prepare('INSERT INTO sections (notebook_id, name, order_index) VALUES (?, ?, ?)').run(notebook_id, name, nextOrder);
    const section = db.prepare('SELECT * FROM sections WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(section);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update section
router.put('/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { name, is_pinned, order_index } = req.body;
    
    const updates = [];
    const values = [];
    
    if (name !== undefined) {
      updates.push('name = ?');
      values.push(name);
    }
    
    if (is_pinned !== undefined) {
      updates.push('is_pinned = ?');
      values.push(is_pinned ? 1 : 0);
    }
    
    if (order_index !== undefined) {
      updates.push('order_index = ?');
      values.push(order_index);
    }
    
    values.push(id);
    
    const query = `UPDATE sections SET ${updates.join(', ')} WHERE id = ?`;
    db.prepare(query).run(...values);
    
    const section = db.prepare('SELECT * FROM sections WHERE id = ?').get(id);
    res.json(section);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete section
router.delete('/:id', (req, res) => {
  try {
    const { id } = req.params;
    db.prepare('DELETE FROM sections WHERE id = ?').run(id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get pages in section
router.get('/:id/pages', (req, res) => {
  try {
    const { id } = req.params;
    const pages = db.prepare(`
      SELECT * FROM pages 
      WHERE section_id = ? 
      ORDER BY is_pinned DESC, order_index ASC, created_at ASC
    `).all(id);
    res.json(pages);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Bulk reorder pages
router.put('/:id/pages/reorder', (req, res) => {
  try {
    const { id } = req.params;
    const { pages } = req.body; // Array of {id, order_index}
    
    const transaction = db.transaction((pages) => {
      for (const page of pages) {
        db.prepare('UPDATE pages SET order_index = ? WHERE id = ? AND section_id = ?')
          .run(page.order_index, page.id, id);
      }
    });
    
    transaction(pages);
    
    const updatedPages = db.prepare(`
      SELECT * FROM pages 
      WHERE section_id = ? 
      ORDER BY is_pinned DESC, order_index ASC, created_at ASC
    `).all(id);
    
    res.json(updatedPages);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
