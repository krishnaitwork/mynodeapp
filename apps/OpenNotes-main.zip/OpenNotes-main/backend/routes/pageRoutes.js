const express = require('express');
const { db } = require('../db/initDatabase');
const { AuthService, JWT_SECRET } = require('../authService');
const jwt = require('jsonwebtoken');

const router = express.Router();

// Get specific page
router.get('/:id', (req, res) => {
  try {
    const { id } = req.params;
    const page = db.prepare('SELECT * FROM pages WHERE id = ?').get(id);
    if (!page) {
      return res.status(404).json({ error: 'Page not found' });
    }
    
    // If page is password protected, enforce unlock header
    if (page.is_password_protected) {
      const unlockHeader = req.header('X-Page-Unlock');
      if (unlockHeader) {
        try {
          const decoded = jwt.verify(unlockHeader, JWT_SECRET);
          if (decoded.pageId && String(decoded.pageId) === String(id) && decoded.type === 'pageUnlock') {
            // valid token; return full page (omit password_hash)
            const { password_hash, ...pageData } = page;
            return res.json(pageData);
          }
        } catch (e) {
          // invalid/expired token -> fall through to locked response
          // Silently ignore invalid token; treated as locked
        }
      }
      const { content, password_hash, ...pageWithoutContent } = page;
      return res.json({
        ...pageWithoutContent,
        content: null,
        isLocked: true
      });
    } else {
      // Not protected
      res.json(page);
    }
  } catch (error) {
    console.error('Error in GET /api/pages/:id:', error);
    res.status(500).json({ error: error.message });
  }
});

// Create new page
router.post('/', (req, res) => {
  try {
    const { section_id, title = 'Untitled Page', content = '' } = req.body;
    if (!section_id) {
      return res.status(400).json({ error: 'Section ID is required' });
    }
    
    // Get the next order index
    const maxOrder = db.prepare('SELECT MAX(order_index) as max_order FROM pages WHERE section_id = ?').get(section_id);
    const nextOrder = (maxOrder.max_order || 0) + 1;
    
    const result = db.prepare('INSERT INTO pages (section_id, title, content, order_index) VALUES (?, ?, ?, ?)').run(section_id, title, content, nextOrder);
    const page = db.prepare('SELECT * FROM pages WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(page);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update page
router.put('/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { title, content, is_pinned, order_index } = req.body;
    
    // First, check if the page is password protected
    const currentPage = db.prepare('SELECT * FROM pages WHERE id = ?').get(id);
    if (!currentPage) {
      return res.status(404).json({ error: 'Page not found' });
    }
    
    // If page is password protected and we're trying to update content to empty/null
    // this might be an attempt to clear content when locked - prevent this
    if (currentPage.is_password_protected && content !== undefined) {
      if (!content || content === '' || content === 'null' || content === null) {
        // Prevent clearing locked page content
        return res.status(403).json({ error: 'Cannot clear content on password protected page' });
      }
    }
    
    const updates = [];
    const values = [];
    
    if (title !== undefined) {
      updates.push('title = ?');
      values.push(title);
    }
    
    if (content !== undefined) {
      updates.push('content = ?');
      // Ensure content is a string (JSON stringify if it's an object)
      const contentString = typeof content === 'string' ? content : JSON.stringify(content);
      values.push(contentString);
    }
    
    if (is_pinned !== undefined) {
      updates.push('is_pinned = ?');
      values.push(is_pinned ? 1 : 0);
    }
    
    if (order_index !== undefined) {
      updates.push('order_index = ?');
      values.push(order_index);
    }

    updates.push('updated_at = CURRENT_TIMESTAMP');
    
    const query = `UPDATE pages SET ${updates.join(', ')} WHERE id = ?`;
    values.push(id);
    
    db.prepare(query).run(...values);
    
    const page = db.prepare('SELECT * FROM pages WHERE id = ?').get(id);
    res.json(page);
  } catch (error) {
    console.error('Error in PUT /api/pages/:id:', error);
    res.status(500).json({ error: error.message });
  }
});

// Delete page
router.delete('/:id', (req, res) => {
  try {
    const { id } = req.params;
    db.prepare('DELETE FROM pages WHERE id = ?').run(id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Set page password
router.post('/:id/set-password', async (req, res) => {
  try {
    const { id } = req.params;
    const { password } = req.body;

    if (!password) {
      return res.status(400).json({ error: 'Password is required' });
    }

    const passwordHash = await AuthService.hashPagePassword(password);
    
    db.prepare('UPDATE pages SET is_password_protected = 1, password_hash = ? WHERE id = ?').run(passwordHash, id);
    
    res.json({ message: 'Page password set successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Remove page password
router.post('/:id/remove-password', (req, res) => {
  try {
    const { id } = req.params;
    
    db.prepare('UPDATE pages SET is_password_protected = 0, password_hash = NULL WHERE id = ?').run(id);
    
    res.json({ message: 'Page password removed successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Verify page password
router.post('/:id/verify-password', async (req, res) => {
  try {
    const { id } = req.params;
    const { password } = req.body;

    const page = db.prepare('SELECT password_hash FROM pages WHERE id = ? AND is_password_protected = 1').get(id);
    if (!page) {
      return res.status(404).json({ error: 'Protected page not found' });
    }

    const isValid = await AuthService.verifyPagePassword(password, page.password_hash);
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid password' });
    }

    res.json({ message: 'Password verified successfully', valid: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Unlock a page with password
router.post('/:id/unlock', async (req, res) => {
  try {
    const { id } = req.params;
    const { password } = req.body;

    const page = db.prepare('SELECT * FROM pages WHERE id = ?').get(id);
    if (!page) {
      return res.status(404).json({ error: 'Page not found' });
    }

    if (!page.is_password_protected) {
      return res.json(page);
    }

    const isValid = await AuthService.verifyPagePassword(password, page.password_hash);
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid password' });
    }

    // Return full page content plus an unlock token (8h)
    const unlockToken = jwt.sign({ pageId: id, type: 'pageUnlock' }, JWT_SECRET, { expiresIn: '8h' });
    const { password_hash, ...pageData } = page;
    res.json({ ...pageData, unlockToken });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
