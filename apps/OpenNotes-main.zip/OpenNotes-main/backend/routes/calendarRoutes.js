const express = require('express');
const router = express.Router();
const calendarDb = require('../db/calendarDatabase');
const dayjs = require('dayjs');

// List tasks - optional query from/to
router.get('/', (req, res) => {
  const { from, to } = req.query;
  try {
    const tasks = calendarDb.listTasks({ fromDate: from, toDate: to });
    res.json(tasks);
  } catch (error) {
    console.error('Failed to list calendar tasks', error);
    res.status(500).json({ error: 'Failed to list tasks' });
  }
});

// Create task
router.post('/', (req, res) => {
  const { title, notes, due_date } = req.body;
  if (!title || !due_date) return res.status(400).json({ error: 'title and due_date are required' });
  try {
    const task = calendarDb.createTask({ title, notes, due_date });
    res.status(201).json(task);
  } catch (error) {
    console.error('Failed to create calendar task', error);
    res.status(500).json({ error: 'Failed to create task' });
  }
});

// Get task
router.get('/:id', (req, res) => {
  const { id } = req.params;
  try {
    const task = calendarDb.getTaskById(id);
    if (!task) return res.status(404).json({ error: 'Task not found' });
    res.json(task);
  } catch (error) {
    console.error('Failed to get task', error);
    res.status(500).json({ error: 'Failed to get task' });
  }
});

// Update task
router.put('/:id', (req, res) => {
  const { id } = req.params;
  const fields = req.body;
  try {
    const updated = calendarDb.updateTask(id, fields);
    res.json(updated);
  } catch (error) {
    console.error('Failed to update task', error);
    res.status(500).json({ error: 'Failed to update task' });
  }
});

// Delete task
router.delete('/:id', (req, res) => {
  const { id } = req.params;
  try {
    calendarDb.deleteTask(id);
    res.json({ success: true });
  } catch (error) {
    console.error('Failed to delete task', error);
    res.status(500).json({ error: 'Failed to delete task' });
  }
});

// Rollover endpoint - moves incomplete tasks due today or earlier to next day
router.post('/rollover', (req, res) => {
  const today = dayjs().format('YYYY-MM-DD');
  try {
    const result = calendarDb.rolloverIncompleteToNextDay(today);
    res.json(result);
  } catch (error) {
    console.error('Failed to rollover tasks', error);
    res.status(500).json({ error: 'Failed to rollover tasks' });
  }
});

module.exports = router;
