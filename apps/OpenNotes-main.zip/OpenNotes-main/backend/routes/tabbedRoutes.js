const express = require('express');
const router = express.Router();
const tabbedDb = require('../db/tabbedDatabase');

router.get('/', (req, res) => {
  const tabs = tabbedDb.listTabs();
  res.json({ tabs });
});

router.get('/:id', (req, res) => {
  const tab = tabbedDb.getTab(req.params.id);
  if (!tab) return res.status(404).json({ error: 'Not found' });
  res.json(tab);
});

router.post('/', (req, res) => {
  const { title, content } = req.body || {};
  const created = tabbedDb.createTab(title || 'Untitled', content || '');
  res.status(201).json(created);
});

router.put('/:id', (req, res) => {
  const { title, content } = req.body || {};
  const updated = tabbedDb.updateTab(req.params.id, { title, content });
  res.json(updated);
});

router.delete('/:id', (req, res) => {
  const del = tabbedDb.deleteTab(req.params.id);
  res.json(del);
});

module.exports = router;
