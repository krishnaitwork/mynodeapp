const express = require('express');
const { db } = require('../db/initDatabase');

const router = express.Router();

// Search pages
router.get('/', (req, res) => {
  try {
    const { q } = req.query;
    if (!q) {
      return res.status(400).json({ error: 'Search query is required' });
    }

    // Limit result set for performance
    const rows = db.prepare(`
      SELECT 
        p.id,
        p.section_id,
        p.title,
        p.updated_at,
        p.is_password_protected,
        p.is_pinned,
        p.order_index,
        CASE WHEN p.is_password_protected = 1 THEN NULL ELSE p.content END AS content,
        s.name AS section_name,
        s.notebook_id AS notebook_id,
        n.name AS notebook_name
      FROM pages p
      JOIN sections s ON p.section_id = s.id
      JOIN notebooks n ON s.notebook_id = n.id
      WHERE (p.title LIKE ? OR p.content LIKE ?)
      ORDER BY p.updated_at DESC
      LIMIT 50
    `).all(`%${q}%`, `%${q}%`);

    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
