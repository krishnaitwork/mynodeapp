# Contributing to OpenNotes

Thanks for your interest in improving OpenNotes! This document explains how to get set up, propose changes, and follow project conventions.

## Development Environment
```
# Clone
git clone <repo-url>
cd OpenNotes

# Install
cd backend && npm install
cd ../frontend && npm install

# Init DB
cd ../backend && npm run init-db

# Run
npm run dev (backend)
# New terminal
npm run dev (frontend)
```

## Branch Strategy
- `main` – stable branch
- `feature/<short-description>` – new features
- `fix/<issue-id-or-keyword>` – bug fixes
- `docs/<topic>` – documentation updates

## Commit Message Format
```
<type>(scope): concise description
```
Types:
- feat: new feature
- fix: bug fix
- docs: documentation only
- refactor: code change w/out feature/bug
- perf: performance improvement
- test: adding/fixing tests
- chore: tooling / build / deps

Example:
```
feat(editor): add multi-occurrence search navigation
```

## Code Style
- Use existing patterns; prefer small pure functions
- Avoid premature abstraction
- Keep components focused (<300 lines ideal)
- Prefer early returns over deep nesting
- Use Tailwind utility classes consistently

## Adding Dependencies
- Justify necessity in PR description
- Prefer lightweight, widely adopted packages

## Testing (Planned)
Future test stack (proposal):
- Backend: Jest + Supertest
- Frontend: Vitest + React Testing Library

When added, include at least:
- Happy path for new endpoint/component
- One edge case (invalid input / empty state)

## Performance Considerations
- Debounce network-heavy actions (search, autosave)
- Avoid redundant fetching (reuse context state)
- Consider virtualization for very long page lists (future)

## Security Considerations
- Never log sensitive secrets or password content
- Validate input server-side
- Keep JWT-related logic isolated in `authService.js`

## PR Checklist
- [ ] Feature / fix described in PR body
- [ ] Updated docs (README / relevant MD files)
- [ ] No console debug logs remain
- [ ] Lint passes (when lint config added)
- [ ] No redundant network calls introduced
- [ ] Protected page logic preserved

## Reporting Bugs
Include:
1. Steps to reproduce
2. Expected vs actual behavior
3. Screenshots / console errors
4. Environment (OS, browser, Node version)

## Proposing Features
Answer:
- What problem does it solve?
- Why is it important?
- Any alternative solutions?
- Rough data model / API changes (if any)

## Documentation Updates
Feel free to improve wording, add diagrams (ASCII / links), or reorganize sections. Keep README concise; push deep dives into dedicated MD files.

## Release Versioning (Future)
Will follow SemVer once versions are tagged:
- MAJOR: breaking API or schema changes
- MINOR: new features backward compatible
- PATCH: bug fixes only

## Community Guidelines
- Be respectful and constructive
- Prefer async written discussion (issues/PR comments)
- Resolve disagreements with data or prototypes

---
Happy hacking! 🔧
