# OpenNotes - OneNote-like Clone

A modern, offline-first, password-protectable note-taking application inspired by Microsoft OneNote. Built with React (Vite), TipTap (ProseMirror), Express, and SQLite. Supports rich text, hierarchical organization, autosave, secure per‑page locking, and multi-occurrence search highlighting.

## 🌟 Features

### ✨ Core Features
- **Hierarchical Organization**: Notebooks → Sections → Pages
- **Rich Text Editing**: Formatting, tables, links, images, code blocks
- **Autosave**: Debounced, intelligent diffing (prevents redundant writes)
- **Multi-Occurrence Search**: Highlight all matches + next/previous navigation
- **In-Editor Highlighting**: ProseMirror decorations for matched terms
- **Per-Page Password Protection**: Content locked until unlocked (8h token)
- **Dark/Light Mode**: System-aware theme persistence
- **Responsive Design**: Desktop, tablet, mobile friendly
- **Offline-First**: File-based SQLite storage
- **Pin & Order**: Pin sections/pages and reorder with indices

### 📝 Rich Text Features
- Bold, italic, underline, strikethrough
- Headings (H1–H3)
- Bullet & numbered lists
- Code blocks & inline code
- Blockquotes
- Tables (header cells, resizable)
- Links (managed, not auto-opening)
- Images (base64 embedded; future upload pipeline)
- Multi-term highlighting via search

### 🎨 Modern UI
- Clean, intuitive interface
- Collapsible sidebar navigation
- Mobile-friendly responsive design
- Smooth animations and transitions
- Professional typography

## 🚀 Getting Started

### Prerequisites
- Node.js (v16 or higher)
- npm or yarn

### Installation

1. **Clone or download the project**
   ```powershell
   git clone <repository-url>
   cd OpenNotes
   ```

2. **Install Backend Dependencies**
   ```powershell
   cd backend
   npm install
   ```

3. **Install Frontend Dependencies**
   ```powershell
   cd ../frontend
   npm install
   ```

4. **Initialize Database**
   ```powershell
   cd ../backend
   npm run init-db
   ```

### Running the Application

1. **Start the Backend Server**
   ```powershell
   cd backend
   npm run dev
   ```
   The backend will start on `http://localhost:5000`

2. **Start the Frontend (in a new terminal)**
   ```powershell
   cd frontend
   npm run dev
   ```
   The frontend will start on `http://localhost:3000`

3. **Open your browser** and navigate to `http://localhost:3000`

## 🏗️ Project Structure (Simplified)

```
OpenNotes/
├── backend/                 # Node.js + Express + SQLite
│   ├── package.json
│   ├── server.js           # Main server file
│   ├── initDatabase.js     # Database setup
│   └── opennotes.db        # SQLite database (created automatically)
├── frontend/               # React + Vite + TailwindCSS
│   ├── package.json
│   ├── vite.config.js
│   ├── tailwind.config.js
│   ├── index.html
│   └── src/
│       ├── App.jsx         # Main app component
│       ├── main.jsx        # Entry point
│       ├── index.css       # Global styles
│       ├── components/     # React components
│       │   ├── Sidebar.jsx
│       │   ├── MainEditor.jsx
│       │   └── RichTextEditor.jsx
│       ├── context/        # React Context for state management
│       │   └── AppContext.jsx
│       └── services/       # API services
│           └── api.js
└── README.md
```

## 🔧 Technology Stack

### Frontend
- **React 18** - Modern React with hooks
- **Vite** - Fast build tool and dev server
- **TailwindCSS** - Utility-first CSS framework
- **TipTap** - Rich text editor built on ProseMirror
- **Lucide React** - Beautiful icon library
- **Axios** - HTTP client for API calls

### Backend
- **Node.js** - JavaScript runtime
- **Express.js** - Web framework
- **SQLite** - Lightweight, file-based database
- **better-sqlite3** - Fast, synchronous SQLite3 binding
- **CORS** - Cross-origin resource sharing

## 📚 API Documentation

### Notebooks
- `GET /api/notebooks` - List all notebooks
- `POST /api/notebooks` - Create new notebook
- `PUT /api/notebooks/:id` - Update notebook name
- `DELETE /api/notebooks/:id` - Delete notebook

### Sections
- `GET /api/notebooks/:id/sections` - List sections in notebook
- `POST /api/sections` - Create new section
- `PUT /api/sections/:id` - Update section name
- `DELETE /api/sections/:id` - Delete section

### Pages
- `GET /api/sections/:id/pages` - List pages in section
- `GET /api/pages/:id` - Get specific page
- `POST /api/pages` - Create new page
- `PUT /api/pages/:id` - Update page (autosave endpoint)
- `DELETE /api/pages/:id` - Delete page

### Search
- `GET /api/search?q=query` - Search across all pages (excluded locked content bodies)

## 🗄️ Database Schema (Core)

```sql
-- Notebooks table
CREATE TABLE notebooks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Sections table
CREATE TABLE sections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  notebook_id INTEGER,
  name TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (notebook_id) REFERENCES notebooks(id) ON DELETE CASCADE
);

-- Pages table
CREATE TABLE pages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  section_id INTEGER,
  title TEXT DEFAULT 'Untitled Page',
  content TEXT DEFAULT '',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (section_id) REFERENCES sections(id) ON DELETE CASCADE
);
```

## ⚡ Autosave Implementation

OpenNotes implements intelligent autosave:

1. **Debounced Saving**: Changes are saved automatically 1 second after the user stops typing
2. **Visual Feedback**: Shows saving status (Saving... → All changes saved)
3. **Optimistic Updates**: UI updates immediately for responsive feel
4. **Error Handling**: Displays error status if saving fails

## 🎨 Responsive Design

- **Desktop**: Full sidebar + main editor layout
- **Tablet**: Collapsible sidebar with overlay
- **Mobile**: Drawer-style sidebar with touch-friendly controls

## 🔐 Password Protection Overview
Per-page passwords are hashed (bcrypt). A successful unlock returns a short-lived JWT (8h) used via `X-Page-Unlock` header to fetch protected content. Search results never include protected page content.

## 🔮 Future Enhancements

- [ ] File & image upload pipeline (object storage)
- [ ] Export (PDF / Markdown)
- [ ] Tagging + filtered search facets
- [ ] Full-text index (FTS5) or external search
- [ ] Real-time collaboration (Y.js / WebSocket)
- [ ] Cloud sync (multi-device)
- [ ] Mobile (React Native / Capacitor)
- [ ] Plugin architecture
- [ ] Drawing / ink canvas
- [ ] Role-based multi-user sharing

## 🐛 Troubleshooting

### Common Issues (See `TROUBLESHOOTING.md` for full guide)
| Issue | Quick Fix |
|-------|-----------|
| Ports in use | Change PORT env / close process |
| Protected page blank | Re-unlock (token expired) |
| Autosave loop | Check content diff logic |
| Search missing page | Page locked or query too short |

### Reset Application
```powershell
cd backend
del opennotes.db
npm run init-db
```

## 🤝 Contributing
See `CONTRIBUTING.md` for workflow, branch naming, and commit message format.

## 📄 License

MIT – see `LICENSE`.

## 🙏 Acknowledgments

- Inspired by Microsoft OneNote
- Built with modern web technologies
- Icons by [Lucide](https://lucide.dev/)
- Rich text editing powered by [TipTap](https://tiptap.dev/)

---

## 📘 Additional Documentation
| File | Purpose |
|------|---------|
| `ARCHITECTURE.md` | Deep dive into system design |
| `OPERATIONS.md` | Runbook & deployment notes |
| `SECURITY.md` | Threat model & hardening tips |
| `TROUBLESHOOTING.md` | Diagnostics & recovery steps |
| `CONTRIBUTING.md` | How to propose changes |
| `DEVELOPMENT.md` | Quick start & workflow |

**Happy Note-Taking! 📝✨**
