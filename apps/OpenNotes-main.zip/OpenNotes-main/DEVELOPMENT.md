# OpenNotes Development

## Project Overview
OpenNotes is a comprehensive note-taking application similar to Microsoft OneNote, built with modern web technologies.

## Quick Start Commands

### First Time Setup
```powershell
# Navigate to project directory
cd "C:\KP\Git\React\OpenNotes"

# Install backend dependencies
cd backend
npm install

# Install frontend dependencies  
cd ..\frontend
npm install

# Initialize database with sample data
cd ..\backend
npm run init-db
```

### Development Workflow
```powershell
# Terminal 1: Start Backend Server
cd "C:\KP\Git\React\OpenNotes\backend"
npm run dev

# Terminal 2: Start Frontend Development Server
cd "C:\KP\Git\React\OpenNotes\frontend"  
npm run dev
```

### Access Points
- Frontend: http://localhost:3000
- Backend API: http://localhost:5000/api
- Health Check: http://localhost:5000/api/health

## Architecture

### Frontend Stack
- React 18 with functional components and hooks
- Vite for fast development and building
- TailwindCSS for styling
- TipTap rich text editor
- Context API for state management
- Axios for API communication

### Backend Stack
- Node.js with Express.js
- SQLite with better-sqlite3
- RESTful API design
- CORS enabled for development

### Key Features Implemented
1. **Hierarchical Structure**: Notebooks → Sections → Pages
2. **Rich Text Editor**: Full WYSIWYG with toolbar
3. **Autosave**: Debounced saving with status indicators
4. **Responsive Design**: Mobile-friendly with sidebar drawer
5. **Dark Mode**: Theme toggle with localStorage persistence
6. **Search**: Full-text search across all content

## Database Design

The application uses SQLite with a three-level hierarchy:

```
Notebooks (id, name, created_at)
    ↓
Sections (id, notebook_id, name, created_at)  
    ↓
Pages (id, section_id, title, content, created_at, updated_at)
```

Content is stored as JSON (TipTap format) in the pages.content field.

## Component Structure

```
App.jsx
├── AppProvider (Context)
├── Sidebar.jsx
│   ├── Notebook selector
│   ├── Section tabs
│   └── Page list
└── MainEditor.jsx
    ├── Top bar (search, theme toggle)
    ├── Page title input
    └── RichTextEditor.jsx (TipTap)
```

## State Management

Uses React Context with useReducer for centralized state:
- notebooks, sections, pages arrays
- currentNotebook, currentSection, currentPage
- UI state (darkMode, sidebarOpen, autosaveStatus)
- loading and error states

## API Design

RESTful endpoints for CRUD operations:
- `/api/notebooks` - Notebook management
- `/api/sections` - Section management  
- `/api/pages` - Page management
- `/api/search` - Full-text search

All endpoints return JSON and include proper error handling.

## Next Steps for Enhancement

1. **Image Support**: Add file upload and image embedding
2. **Advanced Search**: Filters, tags, date ranges
3. **Export Features**: PDF and Markdown export
4. **Collaboration**: Real-time editing support
5. **Cloud Sync**: Backend integration with cloud storage
6. **Mobile Apps**: React Native versions
7. **Plugin System**: Extensible architecture

## Development Notes

- Autosave uses 1-second debouncing to prevent excessive API calls
- Dark mode preference is persisted in localStorage
- Mobile sidebar uses CSS transforms for smooth animations
- Rich text content is stored as JSON for flexibility
- Database includes sample data for immediate testing

The application is production-ready for local use and can be easily extended for additional features.
