# OpenNotes Security Guide

## Current Security Features
- Password-protected pages (per-page secret)
- Page unlock tokens (JWT, 8h expiry) transmitted via `X-Page-Unlock` header
- User authentication (register/login) with bcrypt-hashed passwords & per-user salt
- Protected page content never returned in search results (content null & flag is_password_protected)
- Server-side guard preventing blank overwrite on locked pages

## Threat Model (Simplified)
| Threat | Mitigation | Notes |
|--------|------------|-------|
| Brute force page password | Bcrypt hashing | Consider rate limiting future |
| Replay of unlock token | Expiry + page-specific claim | Add token blacklist if early revoke needed |
| Protected content leakage via search | Conditional NULL content | Verified server-side |
| Autosave wiping protected content | Server rejects empty content update | Frontend also avoids sending when locked |
| Token theft (XSS) | Currently no CSP | Add CSP & sanitize user-generated HTML if enabling raw HTML |

## Password Handling
- User passwords: hashed with bcrypt (salt stored separately if custom scheme or integrated in hash)
- Page passwords: bcrypt as well (two implementations present; unify recommended)
- No plaintext persistence
- Minimum length enforced (users) – extend to pages (recommended)

## JWT
- Claims: `{ userId, username }` for auth tokens, `{ pageId, type: 'pageUnlock' }` for unlock
- Secret: `JWT_SECRET` (move to environment variable; rotate periodically)
- Suggested future: separate secrets for auth vs unlock tokens

## Recommended Improvements
| Area | Action |
|------|--------|
| Rate Limiting | Add express-rate-limit on auth & unlock routes |
| Token Storage | Use HttpOnly Secure cookies instead of local storage (if currently persisted) |
| Input Validation | Add zod / joi schemas for all request bodies |
| Password Policy | Enforce stronger complexity & reuse checks |
| Logging | Mask sensitive fields in error logs |
| Secrets Mgmt | Load via dotenv; restrict file permissions |
| CSRF | If using cookies, add CSRF token validation |
| Content Security Policy | Add helmet middleware with CSP |
| Dependency Updates | Use `npm audit` CI gating |

## Handling Sensitive Incidents
1. Identify scope (which pages / users affected)
2. Rotate `JWT_SECRET` (invalidates existing tokens)
3. Force password resets (add endpoint) if credential leak suspected
4. Archive log evidence; avoid tampering
5. Communicate to users with timeline & remediation steps

## Secure Deployment Checklist
- [ ] Set strong `JWT_SECRET` in environment
- [ ] Enable HTTPS (reverse proxy or platform)
- [ ] Restrict file permissions on `opennotes.db`
- [ ] Daily automated DB backups encrypted at rest
- [ ] Apply rate limiting middleware
- [ ] Enable helmet with CSP, HSTS, X-Frame-Options
- [ ] Monitor auth & unlock endpoint failures for brute force patterns

## Data Privacy
- SQLite file contains all note content (including protected pages)
- For multi-user SaaS, isolate by tenant or migrate to Postgres with row-level security

---
Security evolves; reassess regularly as features expand.
