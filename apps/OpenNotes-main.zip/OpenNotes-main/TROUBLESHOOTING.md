# OpenNotes Troubleshooting Guide

## Quick Diagnostics
| Symptom | Quick Check | Likely Cause | Fix |
|---------|-------------|--------------|-----|
| Frontend 404 to API | Open dev tools Network tab | Backend not running / wrong port | Start backend `npm run dev` |
| Autosave never ends (spins) | Console shows repeated PUT | Content diff always true | Normalize content or clear corrupted page content |
| Search returns no results | Valid term present? | Query < 2 chars or protected page | Use longer term / unlock page |
| Page shows locked banner unexpectedly | Check session storage token | Unlock token expired | Re-enter page password |
| Password accepted but content blank | Network tab: GET page missing header | Header not sent | Ensure unlock logic sets token |
| Database file not updating | Timestamp unchanged | Running in different folder | Confirm working directory & path |

## Detailed Scenarios
### 1. Backend Port Already in Use
Error: `EADDRINUSE: address already in use :::5000`
Resolution:
```
# Find process (Windows)
netstat -ano | findstr :5000
# Kill process
Taskkill /PID <pid> /F
```
Or change port: set `PORT=5001` env variable before start.

### 2. Corrupted Database
Symptoms: SQL errors or missing tables.
Steps:
```
cd backend
copy opennotes.db opennotes.backup
del opennotes.db
npm run init-db
```
Optionally re-import user data manually.

### 3. Autosave Flood
- Inspect `MainEditor` autosave effect
- Confirm lastSavedRef updates after successful PUT
- Check network panel for 403 (protected blank update)
- If loop persists: temporarily disable autosave by early return in effect

### 4. Protected Page Unlock Fails
Checks:
1. POST /api/pages/:id/unlock returns 200?
2. Response includes `unlockToken`?
3. Subsequent GET includes `X-Page-Unlock` header?
4. Time between unlock and GET < 8h?

### 5. Images Not Appearing
- Confirm base64 string size < body limit (10mb)
- Check console for TipTap errors
- Verify `@tiptap/extension-image` installed

### 6. Search Highlight Not Working
- Ensure highlight term set (length > 0)
- Confirm decoration plugin dispatch triggered (meta `searchHighlight`)
- Check CSS: `.search-highlight` class not overridden

### 7. Performance Lag on Large Pages
- Too many decorations (very long repeated terms) → narrow search term
- Consider splitting large page into section subpages

### 8. Login Fails After Secret Rotation
- Existing tokens invalid; re-login
- Clear local storage/session storage items

## Logging Tips
Add temporary debug:
```
console.log('Autosave diff', { currentLen: content.length, lastLen: lastSavedRef.current.length });
```
Remove after resolving.

## Support Bundle Checklist
Collect:
- Browser HAR export
- Console log screenshot
- `server.js` console output snippet
- `/api/health` response
- App version (commit hash / tag)

---
If unresolved after steps above, create an issue with reproduction details.
