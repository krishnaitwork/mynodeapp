# OpenNotes Architecture

## Overview
OpenNotes is a full-stack note-taking application inspired by OneNote. It implements a three-level hierarchy (Notebooks → Sections → Pages) with rich text editing, autosave, search, and per-page password protection.

## High-Level Diagram
```
[ React (Vite) SPA ]  <--Axios-->  [ Express API Layer ]  --(better-sqlite3)-->  [ SQLite DB ]
       |                                        |                                |
  TipTap Editor <---- local state (Context) ----+                                +-- File-based storage
```

## Frontend
- React 18 + Vite
- State: React Context + useReducer (no external state lib)
- Editor: TipTap (ProseMirror) with custom extensions (image, table, link, underline, search highlight)
- Styling: TailwindCSS
- Routing: (optional/placeholder) react-router-dom available
- Autosave: Debounced (≈1.2s idle) with content normalization to prevent redundant PUT calls
- Search: Debounced query → highlight with ProseMirror decorations + multi-occurrence navigation

### Frontend Data Flow
1. User selects notebook → sections fetched (if not cached)
2. User selects section → pages fetched
3. User selects page → content loaded (guarded if password protected)
4. User types → editor state updates → debounced autosave (PUT /api/pages/:id)
5. Search input → debounce → GET /api/search → user picks result → navigate & highlight term

### Key Components
- `AppContext` – Holds global state (notebooks, sections, pages, current selections, autosave status)
- `Sidebar` – Hierarchical navigation
- `MainEditor` – Coordinates page loading, password unlock, search integration, autosave
- `RichTextEditor` – TipTap instance, multi-match search highlighting & navigation overlay
- `PagePasswordModal` – Set / verify / remove page-level password

### Editor Extensions Used
- StarterKit (paragraph, text, bold, italic, strike, heading, list, code, blockquote, history)
- Underline
- Link (configured openOnClick: false)
- Table (with row/header/cell sub-extensions, resizable)
- Image (base64 inline allowed for local/offline use)
- Custom SearchHighlight (ProseMirror decoration plugin)

## Backend
- Node.js + Express
- better-sqlite3 (synchronous, fast, simple transactions)
- JWT for authentication (user login and per-page unlock tokens)
- Password hashing: bcrypt for users and pages (plus optional custom helpers in `authService.js`)
- Multer included (future file upload support)
- Single process – no clustering (sufficient for local / small deployments)

### API Responsibilities
- CRUD for notebooks, sections, pages
- Ordering & pinning (order_index, is_pinned)
- Search (title + content LIKE pattern, limited to 50 results)
- Page password protection (set/remove/verify/unlock) with unlock token header enforcement
- Authentication endpoints (register/login/verify/me)

### Password Protection Flow
1. Protected page GET without unlock header → returns metadata (content: null, isLocked: true)
2. User submits password → POST /api/pages/:id/unlock → server verifies and returns page + `unlockToken`
3. Frontend stores token (session scope) and sends it as `X-Page-Unlock` header on subsequent GET /api/pages/:id
4. Autosave guarded from wiping content on locked pages (backend rejects blank replacement for protected pages)

### Database Schema (Extended)
Adds security & ordering columns beyond base schema:
```
notebooks(id, name, created_at)
sections(id, notebook_id, name, created_at, is_pinned, order_index)
pages(id, section_id, title, content, created_at, updated_at,
      is_pinned, order_index,
      is_password_protected, password_hash)
users(id, username, password_hash, salt, created_at)
```

### Indexing Considerations
For larger datasets, consider adding indexes:
```
CREATE INDEX IF NOT EXISTS idx_sections_notebook ON sections(notebook_id);
CREATE INDEX IF NOT EXISTS idx_pages_section ON pages(section_id);
CREATE INDEX IF NOT EXISTS idx_pages_updated ON pages(updated_at);
CREATE INDEX IF NOT EXISTS idx_pages_title ON pages(title);
```

## Autosave Strategy
- Local editor content serialized to JSON string
- Cleaned / normalized before comparison to lastSavedRef
- If different and idle period elapsed → PUT update
- Server updates `updated_at` and returns full page

## Search Highlight Strategy
- Frontend collects match positions via doc traversal (for navigation)
- Decoration plugin recomputes inline `search-highlight` spans on term change or doc change
- Navigation overlay provides prev/next with wrap-around and index display

## Security Notes
- JWT secret stored in server memory (for production move to environment variable)
- Unlock tokens limited to 8h lifespan
- Protected pages never leak content in search results (content returned null)
- Attempts to blank protected content via autosave are rejected (403)

## Scaling & Future Hardening
| Area | Today | Future Enhancement |
|------|-------|--------------------|
| Auth | Single JWT secret | Refresh tokens, rotation |
| DB | SQLite file | Postgres + Prisma/Drizzle |
| Editor Assets | Base64 images | S3/object storage + signed URLs |
| Search | LIKE queries | SQLite FTS5 / External search engine |
| Realtime | None | WebSockets / CRDT (Y.js) |
| Tests | Manual | Jest + Supertest + React Testing Library |

## Deployment Outline
1. Build frontend (`npm run build` in `frontend/`) – outputs static assets
2. Serve backend + static files (optionally copy dist to backend/public and add express static middleware)
3. Set env vars (PORT, JWT_SECRET, NODE_ENV)
4. Provide persistent volume for SQLite file

## Monitoring Hooks (Proposed)
- Add `/api/health` (already present) for uptime checks
- Wrap db calls with timing logs (optional) for slow query detection
- Count autosave frequency per page to watch for loops/regressions

---
This document reflects current implemented architecture plus forward-looking suggestions.
